// CostPilot — Projects list screen (RTL). Search on top, status filters, list.
// Reuses shared pieces exported by costpilot-home.jsx.
const { T, Ic, ProjectCard, CostPilotLogo, BottomNav } = window;

const PROJECTS = [
  { name: 'בניית בית ספר רמות',        num: '2024-118', status: 'פעיל',  used: 11420000, total: 18400000, consultants: 9,  accounts: 14 },
  { name: 'מבנה ציבור שכונת הדר',      num: '2023-204', status: 'פעיל',  used: 19116000, total: 23600000, consultants: 12, accounts: 27 },
  { name: 'אולם ספורט עירוני',          num: '2023-167', status: 'פעיל',  used: 7240000,  total: 14800000, consultants: 7,  accounts: 9  },
  { name: 'שיפוץ מרכז קהילתי',          num: '2024-090', status: 'תכנון', used: 496000,   total: 6200000,  consultants: 4,  accounts: 1  },
  { name: 'מעון יום שכונת הפרחים',      num: '2024-145', status: 'תכנון', used: 0,        total: 4900000,  consultants: 3,  accounts: 0  },
  { name: 'ספרייה עירונית מרכזית',      num: '2023-088', status: 'פעיל',  used: 12880000, total: 15200000, consultants: 10, accounts: 19 },
  { name: 'שדרוג כיכר העצמאות',         num: '2024-033', status: 'מושהה', used: 2310000,  total: 8400000,  consultants: 5,  accounts: 4  },
  { name: 'גן ילדים נווה אילן',         num: '2022-051', status: 'הושלם', used: 5640000,  total: 5800000,  consultants: 6,  accounts: 22 },
];

const STATUS_FILTERS = ['הכל', 'פעיל', 'תכנון', 'הושלם', 'מושהה'];

function FilterChip({ label, active }) {
  return (
    <div style={{
      flexShrink: 0, padding: '7px 15px', borderRadius: 6, fontSize: 13, fontWeight: active ? 700 : 500,
      cursor: 'pointer', whiteSpace: 'nowrap',
      background: active ? T.navy900 : '#fff',
      color: active ? '#fff' : T.g600,
      border: `1px solid ${active ? T.navy900 : T.border}`,
    }}>{label}</div>
  );
}

function ProjectsScreen({ platform = 'ios' }) {
  const topPad = platform === 'ios' ? 58 : 12;

  return (
    <div dir="rtl" style={{ height: '100%', display: 'flex', flexDirection: 'column',
      fontFamily: "'Heebo', system-ui, sans-serif", background: T.page, color: T.g950,
      WebkitFontSmoothing: 'antialiased' }}>

      {/* App bar — white, exact app logo */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${T.border}`, padding: `${topPad}px 16px 11px`,
        flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <CostPilotLogo />
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ position: 'relative', width: 38, height: 38, borderRadius: 8,
            background: T.navy50, border: `1px solid ${T.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {Ic.bell(T.navy900)}
            <span style={{ position: 'absolute', top: 7, left: 8, width: 8, height: 8, borderRadius: '50%',
              background: '#C0392B', border: '1.5px solid #fff' }} />
          </div>
          <div style={{ width: 38, height: 38, borderRadius: '50%', background: T.teal600, color: '#fff',
            fontSize: 15, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>עי</div>
        </div>
      </div>

      {/* Title + search + filters (sticky-feeling white block) */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${T.border}`, padding: '14px 16px 12px', flexShrink: 0 }}>
        {/* title row */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 12 }}>
          <h1 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: T.g950, letterSpacing: '-0.01em' }}>פרויקטים</h1>
          <span style={{ fontSize: 13, fontWeight: 700, color: T.navy700, background: T.navy50,
            borderRadius: 20, padding: '2px 9px', lineHeight: 1.5 }}>{PROJECTS.length}</span>
          <div style={{ flex: 1 }} />
          <button style={{ display: 'flex', alignItems: 'center', gap: 5, background: T.navy900, color: '#fff',
            border: 'none', borderRadius: 4, padding: '8px 13px', fontSize: 13, fontWeight: 600,
            fontFamily: 'inherit', cursor: 'pointer' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#fff" strokeWidth="2" strokeLinecap="round"/></svg>
            פרויקט חדש
          </button>
        </div>

        {/* search */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, background: T.page,
          border: `1px solid ${T.border}`, borderRadius: 4, padding: '0 12px', height: 42 }}>
          {Ic.search(T.g400)}
          <span style={{ flex: 1, fontSize: 14, color: T.g400 }}>חיפוש חופשי...</span>
        </div>

        {/* status filters */}
        <div style={{ display: 'flex', gap: 8, marginTop: 12, overflowX: 'auto' }}>
          {STATUS_FILTERS.map((f, i) => <FilterChip key={f} label={f} active={i === 0} />)}
        </div>
      </div>

      {/* List */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px 22px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
          {PROJECTS.map((p, i) => <ProjectCard key={i} p={p} />)}
        </div>
      </div>

      {/* Bottom nav — projects active */}
      <div style={{ flexShrink: 0 }}>
        <BottomNav platform={platform} active="projects" />
      </div>
    </div>
  );
}

Object.assign(window, { ProjectsScreen });
