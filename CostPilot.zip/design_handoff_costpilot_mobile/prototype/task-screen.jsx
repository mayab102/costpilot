// CostPilot — Task detail screen, opened from a dashboard action item.
// Models the "ממתין לאישור מנהל פרויקט" invoice-approval task.
// Reuses shared tokens/components from costpilot-home.jsx.
const { T: TT, StatusBadge: SBadge, fmtILS: ils, BottomNav: TNav } = window;

// local icons (outline, 1.5–1.7px) ------------------------------------------------
const TIc = {
  back: (c) => <svg width="11" height="19" viewBox="0 0 11 19" fill="none"><path d="M1.5 1.5 9 9.5l-7.5 8" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  kebab: (c) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="5" r="1.6" fill={c}/><circle cx="12" cy="12" r="1.6" fill={c}/><circle cx="12" cy="19" r="1.6" fill={c}/></svg>,
  phone: (c) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6.5 3h3l1.5 4-2 1.5a12 12 0 0 0 4.5 4.5L15 15l4 1.5v3a1.5 1.5 0 0 1-1.6 1.5A15.5 15.5 0 0 1 3 5.6 1.5 1.5 0 0 1 4.5 4l2-1Z" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/></svg>,
  mail: (c) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2" stroke={c} strokeWidth="1.6"/><path d="m4 7 8 6 8-6" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  check: (c) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M4 12.5 9.5 18 20 6.5" stroke={c} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  ret: (c) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 7 4 12l5 5" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/><path d="M4 12h11a5 5 0 0 1 5 5v1" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  doc: (c) => <svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5Z" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/><path d="M14 3v5h5" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/></svg>,
};

const TASK = {
  zone: { bg: '#EAF1FA', fg: '#163356', dot: '#2A5A8C' },
  status: 'ממתין לאישור מנהל פרויקט',
  waiting: 'ממתין 3 ימים',
  required: 'אישור חשבון יועץ קונסטרוקציה',
  amount: 124500,
  project: 'בניית בית ספר רמות', projNum: '2024-118', projStatus: 'פעיל',
  field: 'קונסטרוקציה',
  consultant: 'ש. לוי מהנדסים בע״מ', phone: '03-6471120', email: 'office@levi-eng.co.il',
  invoiceNum: '7', receiptDate: '16/06/2026', stagePct: 50,
  contract: 622500, paidBefore: 186750,
  // required milestone (the one this invoice claims)
  msName: 'קבלת היתר בנייה',
  msPct: 25, msValue: 155625, msPaid: 31125, msRequested: 124500, msRemaining: 0,
  milestones: [
    { name: 'חתימת הסכם',            pct: 10, amount: 62250,  paid: 62250,  now: 0,      state: 'paid' },
    { name: 'תכנון מוקדם',            pct: 15, amount: 93375,  paid: 93375,  now: 0,      state: 'paid' },
    { name: 'קבלת היתר בנייה',        pct: 25, amount: 155625, paid: 31125,  now: 124500, state: 'current' },
    { name: 'תכנון מפורט',            pct: 20, amount: 124500, paid: 0,      now: 0,      state: 'todo' },
    { name: 'פיקוח עליון בביצוע',     pct: 20, amount: 124500, paid: 0,      now: 0,      state: 'todo' },
    { name: 'מסירה וטופס 4',          pct: 10, amount: 62250,  paid: 0,      now: 0,      state: 'todo' },
  ],
};

function Row({ label, value, mono, strong, last }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '11px 0', borderBottom: last ? 'none' : `1px solid ${TT.g100}` }}>
      <span style={{ fontSize: 13, color: TT.g500, fontWeight: 500 }}>{label}</span>
      <span style={{ fontSize: strong ? 15 : 13.5, fontWeight: strong ? 800 : 600,
        color: strong ? TT.g950 : TT.g800, fontFamily: "'Heebo', sans-serif" }}>{value}</span>
    </div>
  );
}

function CardBox({ title, children, style }) {
  return (
    <div style={{ background: '#fff', border: `1px solid ${TT.border}`, borderRadius: 8,
      boxShadow: '0 1px 3px rgba(0,0,0,0.05)', padding: '4px 15px', ...style }}>
      {title && <div style={{ fontSize: 12, fontWeight: 700, color: TT.navy700, letterSpacing: '0.04em',
        padding: '12px 0 2px' }}>{title}</div>}
      {children}
    </div>
  );
}

function TimelineStep({ label, sub, state }) {
  // state: 'done' | 'active' | 'todo'
  const color = state === 'done' ? TT.teal600 : state === 'active' ? TT.navy900 : TT.g300;
  return (
    <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
        <div style={{ width: 18, height: 18, borderRadius: '50%', flexShrink: 0,
          background: state === 'todo' ? '#fff' : color,
          border: `2px solid ${color}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {state === 'done' && <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M5 12.5 10 17 19 7" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg>}
          {state === 'active' && <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#fff' }} />}
        </div>
        {sub !== '__last__' && <div style={{ width: 2, height: 26, background: state === 'done' ? TT.teal600 : TT.g200 }} />}
      </div>
      <div style={{ paddingBottom: 14, marginTop: -1 }}>
        <div style={{ fontSize: 13.5, fontWeight: state === 'active' ? 700 : 600,
          color: state === 'todo' ? TT.g400 : TT.g900 }}>{label}</div>
        {sub && sub !== '__last__' && <div style={{ fontSize: 12, color: TT.g500, marginTop: 1 }}>{sub}</div>}
      </div>
    </div>
  );
}

function TaskScreen({ platform = 'ios' }) {
  const topPad = platform === 'ios' ? 56 : 12;
  const t = TASK;
  const paidAfter = t.paidBefore + t.amount;
  const pctBefore = Math.round((t.paidBefore / t.contract) * 100);
  const pctAfter = Math.round((paidAfter / t.contract) * 100);

  return (
    <div dir="rtl" style={{ height: '100%', display: 'flex', flexDirection: 'column',
      fontFamily: "'Heebo', system-ui, sans-serif", background: TT.page, color: TT.g950,
      WebkitFontSmoothing: 'antialiased' }}>

      {/* App bar — shows the project (what this task belongs to) */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${TT.border}`, padding: `${topPad}px 8px 9px`,
        flexShrink: 0, display: 'flex', alignItems: 'center' }}>
        <button style={{ width: 40, height: 40, border: 'none', background: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{TIc.back(TT.navy900)}</button>
        <div style={{ flex: 1, textAlign: 'center', padding: '0 6px' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: TT.g950, lineHeight: 1.2 }}>{t.project}</div>
          <div style={{ fontSize: 11.5, color: TT.g500, marginTop: 1 }}>פרויקט #{t.projNum}</div>
        </div>
        <button style={{ width: 40, height: 40, border: 'none', background: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{TIc.kebab(TT.g600)}</button>
      </div>

      {/* Scroll body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px 20px', display: 'flex',
        flexDirection: 'column', gap: 13 }}>

        {/* Status banner */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '12px 16px',
          background: t.zone.bg, border: `1px solid ${TT.border}`, borderRadius: 8 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: t.zone.dot }} />
          <span style={{ fontSize: 13, fontWeight: 700, color: t.zone.fg }}>{t.status}</span>
          <div style={{ flex: 1 }} />
          <span style={{ fontSize: 12, fontWeight: 600, color: '#A03030',
            background: '#F8EDED', borderRadius: 20, padding: '3px 10px' }}>{t.waiting}</span>
        </div>

        {/* Field + consultant (replaces the project-name row) */}
        <CardBox title="תחום ויועץ" style={{ padding: '4px 15px 14px' }}>
          <Row label="תחום" value={t.field} />
          <Row label="יועץ" value={t.consultant} last />
          <div style={{ display: 'flex', gap: 9, marginTop: 12 }}>
            <ContactBtn icon={TIc.phone(TT.navy700)} label="התקשרות" />
            <ContactBtn icon={TIc.mail(TT.navy700)} label="דוא״ל" />
          </div>
        </CardBox>

        {/* Invoice details */}
        <CardBox title="פרטי החשבון">
          <Row label="מספר חשבון" value={t.invoiceNum} />
          <Row label="תאריך הגשה" value={t.receiptDate} />
          <Row label="סכום לאישור" value={ils(t.amount)} strong last />
        </CardBox>

        {/* Required milestone — full breakdown */}
        <CardBox title="אבן הדרך לאישור" style={{ padding: '4px 15px 16px' }}>
          <div style={{ display:'flex', alignItems:'center', gap:9, background:TT.navy50, border:'1px solid #C4D6EC',
            borderRadius:7, padding:'10px 12px', marginBottom:4 }}>
            <div style={{ width:18,height:18,borderRadius:'50%',background:TT.navy900,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0 }}>
              <span style={{ width:7,height:7,borderRadius:'50%',background:'#fff' }} />
            </div>
            <span style={{ fontSize:14.5, fontWeight:700, color:TT.g950 }}>{t.msName}</span>
          </div>
          <Row label="שיעור אבן הדרך מהחוזה" value={t.msPct + '%'} />
          <Row label="שווי אבן הדרך" value={ils(t.msValue)} />
          <Row label="שולם עד כה מאבן הדרך" value={`${ils(t.msPaid)} · ${Math.round(t.msPaid/t.msValue*100)}%`} />
          <Row label="נדרש בחשבון זה" value={ils(t.msRequested)} strong />
          <Row label="יתרת אבן הדרך לאחר אישור" value={ils(t.msRemaining)} last />
          <div style={{ height:8, borderRadius:4, background:TT.g100, overflow:'hidden', marginTop:10, position:'relative' }}>
            <div style={{ position:'absolute', inset:0, width: Math.round((t.msPaid+t.msRequested)/t.msValue*100)+'%', background:TT.teal100 }} />
            <div style={{ position:'absolute', inset:0, width: Math.round(t.msPaid/t.msValue*100)+'%', background:TT.teal600 }} />
          </div>
          <div style={{ display:'flex', gap:16, marginTop:9 }}>
            <Legend color={TT.teal600} label="שולם מאבן הדרך" />
            <Legend color={TT.teal100} label="נדרש בחשבון זה" />
          </div>
        </CardBox>

        {/* All payment milestones — table */}
        <CardBox title="אבני דרך לתשלום" style={{ padding: '4px 11px 12px' }}>
          <MilestonesTable rows={t.milestones} />
        </CardBox>

        {/* Contract progress */}
        <CardBox title="מול חוזה היועץ" style={{ padding: '4px 15px 16px' }}>
          <Row label="חוזה היועץ" value={ils(t.contract)} />
          <Row label="שולם עד כה" value={`${ils(t.paidBefore)} · ${pctBefore}%`} />
          <Row label="לאחר אישור החשבון" value={`${ils(paidAfter)} · ${pctAfter}%`} last />
          <div style={{ height: 8, borderRadius: 4, background: TT.g100, overflow: 'hidden', marginTop: 10, position: 'relative' }}>
            <div style={{ position: 'absolute', inset: 0, width: pctAfter + '%', background: TT.teal100 }} />
            <div style={{ position: 'absolute', inset: 0, width: pctBefore + '%', background: TT.teal600 }} />
          </div>
          <div style={{ display: 'flex', gap: 16, marginTop: 9 }}>
            <Legend color={TT.teal600} label="שולם" />
            <Legend color={TT.teal100} label="חשבון נוכחי" />
          </div>
        </CardBox>

        {/* Consultant card merged into the field+consultant row above */}

        {/* Timeline */}
        <CardBox title="מהלך הטיפול" style={{ padding: '4px 15px 6px' }}>
          <div style={{ paddingTop: 12 }}>
            <TimelineStep state="done"   label="הוגש על ידי היועץ" sub={t.receiptDate} />
            <TimelineStep state="active" label="ממתין לאישורך — מנהל פרויקט" sub="כעת" />
            <TimelineStep state="todo"   label="אישור מנהל יחידה" sub="__last__" />
          </div>
        </CardBox>
      </div>

      {/* Sticky action footer */}
      <div style={{ flexShrink: 0, background: '#fff', borderTop: `1px solid ${TT.border}`,
        padding: '12px 16px', boxShadow: '0 -2px 10px rgba(0,0,0,0.04)' }}>
        <button style={{ width: '100%', height: 48, border: 'none', borderRadius: 6, cursor: 'pointer',
          background: TT.teal600, color: '#fff', fontSize: 16, fontWeight: 700, fontFamily: 'inherit',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          {TIc.check('#fff')} אישור החשבון
        </button>
        <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
          <button style={{ flex: 1, height: 44, borderRadius: 6, cursor: 'pointer', background: '#fff',
            border: `1px solid ${TT.border}`, color: TT.navy900, fontSize: 14.5, fontWeight: 600, fontFamily: 'inherit',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7 }}>
            {TIc.ret(TT.navy700)} החזרה לתיקון
          </button>
          <button style={{ flex: 1, height: 44, borderRadius: 6, cursor: 'pointer', background: '#fff',
            border: `1px solid ${TT.dangBd}`, color: TT.dangFg, fontSize: 14.5, fontWeight: 600, fontFamily: 'inherit' }}>
            דחייה
          </button>
        </div>
      </div>

      {/* Global bottom nav */}
      <div style={{ flexShrink: 0 }}>
        <TNav platform={platform} active="projects" />
      </div>
    </div>
  );
}

function MilestonesTable({ rows }) {
  const totVal = rows.reduce((s, m) => s + m.amount, 0);
  const totPaid = rows.reduce((s, m) => s + m.paid, 0);
  const totNow = rows.reduce((s, m) => s + m.now, 0);
  const pctOf = (a, b) => b ? Math.round(a / b * 100) + '%' : '—';
  const num = { padding: '8px 8px', fontSize: 11, textAlign: 'right', whiteSpace: 'nowrap',
    fontFamily: "'Heebo', sans-serif", verticalAlign: 'middle' };
  const numHead = { ...num, color: TT.g500, fontWeight: 600, fontSize: 10 };
  const dotFor = (st) => st === 'paid' ? TT.teal600 : st === 'current' ? TT.navy900 : TT.g300;

  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', direction: 'rtl', tableLayout: 'fixed' }}>
      <colgroup>
        <col style={{ width: 'auto' }} /><col style={{ width: 42 }} /><col style={{ width: 52 }} /><col style={{ width: 48 }} /><col style={{ width: 62 }} />
      </colgroup>
      <thead>
        <tr style={{ background: '#F7F8FA', borderBottom: `1px solid ${TT.border}` }}>
          <th style={{ padding: '8px 5px', fontSize: 10, fontWeight: 600, color: TT.g500, textAlign: 'right' }}>אבן הדרך</th>
          <th style={numHead}>אחוז</th>
          <th style={numHead}>% ששולם</th>
          <th style={numHead}>% כעת</th>
          <th style={numHead}>לתשלום</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((m, i) => {
          const cur = m.state === 'current';
          return (
            <tr key={i} style={{ background: cur ? TT.navy50 : 'transparent', borderBottom: `1px solid ${TT.g100}` }}>
              <td style={{ padding: '8px 5px', textAlign: 'right', verticalAlign: 'middle' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <span style={{ width: 9, height: 9, borderRadius: '50%', flexShrink: 0,
                    background: m.state === 'todo' ? '#fff' : dotFor(m.state),
                    border: `1.5px solid ${dotFor(m.state)}` }} />
                  <span style={{ fontSize: 12, fontWeight: cur ? 700 : 600,
                    color: m.state === 'todo' ? TT.g600 : TT.g900, lineHeight: 1.2 }}>{m.name}</span>
                </div>
              </td>
              <td style={{ ...num, color: TT.g700, fontWeight: 600 }}>{m.pct}%</td>
              <td style={{ ...num, color: m.paid ? TT.teal600 : TT.g400, fontWeight: 600 }}>{pctOf(m.paid, m.amount)}</td>
              <td style={{ ...num, color: m.now ? TT.navy900 : TT.g400, fontWeight: cur ? 800 : 600 }}>{m.now ? pctOf(m.now, m.amount) : '—'}</td>
              <td style={{ ...num, color: m.now ? TT.g950 : TT.g400, fontWeight: cur ? 800 : 600 }}>{m.now ? ils(m.now) : '—'}</td>
            </tr>
          );
        })}
        <tr style={{ background: '#F7F8FA', borderTop: `2px solid ${TT.border}` }}>
          <td style={{ padding: '8px 5px', fontSize: 12, fontWeight: 800, color: TT.g950, textAlign: 'right' }}>סה״כ</td>
          <td style={{ ...num, color: TT.g950, fontWeight: 800 }}>100%</td>
          <td style={{ ...num, color: TT.g950, fontWeight: 800 }}>{pctOf(totPaid, totVal)}</td>
          <td style={{ ...num, color: TT.g950, fontWeight: 800 }}>{pctOf(totNow, totVal)}</td>
          <td style={{ ...num, color: TT.g950, fontWeight: 800 }}>{ils(totNow)}</td>
        </tr>
      </tbody>
    </table>
  );
}

function Legend({ color, label }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <span style={{ width: 10, height: 10, borderRadius: 3, background: color }} />
      <span style={{ fontSize: 11.5, color: TT.g500, fontWeight: 500 }}>{label}</span>
    </div>
  );
}

function ContactBtn({ icon, label }) {
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
      height: 40, borderRadius: 6, background: TT.navy50, border: `1px solid ${TT.border}`,
      fontSize: 13.5, fontWeight: 600, color: TT.navy900, cursor: 'pointer' }}>
      {icon}{label}
    </div>
  );
}

Object.assign(window, { TaskScreen });
