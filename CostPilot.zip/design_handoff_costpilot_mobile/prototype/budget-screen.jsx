// CostPilot — Project budget screen ("תקציב הפרויקט"), opened from a project.
// Top: 4 budget metrics + utilization bar. Then three budget sections as
// tables: consultants (תחום/יועץ), fees (אגרות), overheads (תקורות).
// Columns: contract (התקשרות), cumulative paid (מצטבר), remaining (יתרה).
const { T: BT, fmtILS: bils, BottomNav: BNav } = window;

// Compact currency for tight table cells: ₪5.97M / ₪514K / ₪0
const bshort = (n) => {
  const a = Math.abs(n);
  if (a >= 1000000) { let v = (n / 1000000).toFixed(2).replace(/\.?0+$/, ''); return '₪' + v + 'M'; }
  if (a >= 1000) return '₪' + Math.round(n / 1000) + 'K';
  return '₪' + n;
};

const BIcons = {
  back: (c) => <svg width="11" height="19" viewBox="0 0 11 19" fill="none"><path d="M1.5 1.5 9 9.5l-7.5 8" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  check: (c) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M5 12.5 10 17 19 7" stroke={c} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg>,
};

const BUDGET = {
  contractorEst: 14200000,   // אומדן קבלני עדכני
  approved: 18400000,        // תקציב שאושר
  approvedDate: '03/2024',
  used: 11420000,            // ניצול תקציבי (₪)
  consultants: [
    { main: 'אדריכלות',      sub: 'משה אדריכלים בע״מ',   contract: 420000, paid: 285000 },
    { main: 'קונסטרוקציה',   sub: 'ש. לוי מהנדסים בע״מ', contract: 276000, paid: 155625 },
    { main: 'אינסטלציה',     sub: 'מערכות מים בע״מ',      contract: 168000, paid: 92000 },
    { main: 'חשמל',          sub: 'אלקטרה תכנון',         contract: 145000, paid: 60000 },
    { main: 'מיזוג אוויר',   sub: 'קלימה הנדסה',          contract: 98000,  paid: 0 },
    { main: 'בטיחות אש',     sub: 'שלהבת יועצים',         contract: 52000,  paid: 52000 },
  ],
  fees: [
    { main: 'תאגיד המים',     contract: 240000, paid: 120000 },
    { main: 'חברת חשמל (חח״י)', contract: 85000, paid: 40000 },
    { main: 'רשות העתיקות',   contract: 35000,  paid: 0 },
    { main: 'פיצויי נופי',    contract: 18000,  paid: 18000 },
    { main: 'כיבוי אש',       contract: 12000,  paid: 0 },
    { main: 'בזק',            contract: 9000,   paid: 9000 },
    { main: 'תיק מידע',       contract: 6000,   paid: 6000 },
  ],
  overheads: [
    { main: 'תקורות חברה עירונית', sub: '8%',  contract: 1136000, paid: 480000 },
    { main: 'בצ״מ',                sub: '5%',  contract: 710000,  paid: 0 },
    { main: 'מע״מ',                sub: '18%', contract: 2556000, paid: 1100000 },
  ],
};

function Metric({ label, value, sub, badge, accent }) {
  return (
    <div style={{ flex: 1, minWidth: 0, background: BT.card, border: `1px solid ${BT.border}`,
      borderRadius: 8, boxShadow: '0 1px 3px rgba(0,0,0,0.05)', padding: '10px 12px' }}>
      <div style={{ fontSize: 11.5, color: BT.g500, fontWeight: 500, lineHeight: 1.2, whiteSpace: 'nowrap',
        overflow: 'hidden', textOverflow: 'ellipsis' }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 5 }}>
        <span style={{ fontSize: 18, fontWeight: 800, color: accent || BT.navy900, letterSpacing: '-0.01em',
          lineHeight: 1 }}>{value}</span>
        {badge && (
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, fontSize: 10.5, fontWeight: 700,
            color: '#1C4532', background: BT.teal50, borderRadius: 4, padding: '2px 6px' }}>
            {BIcons.check('#2E7D56')}{badge}
          </span>
        )}
      </div>
      <div style={{ fontSize: 11.5, color: BT.g500, marginTop: 3, minHeight: 15 }}>{sub || '\u00A0'}</div>
    </div>
  );
}

function BudgetTable({ sections }) {
  const num = { padding: '8px 5px', fontSize: 10.5, textAlign: 'right', whiteSpace: 'nowrap',
    fontFamily: "'Heebo', sans-serif", verticalAlign: 'middle' };
  const numHead = { ...num, color: BT.g500, fontWeight: 600, fontSize: 9.5 };
  let gC = 0, gP = 0;
  sections.forEach(s => s.rows.forEach(r => { gC += r.contract; gP += r.paid; }));

  return (
    <div style={{ background: BT.card, border: `1px solid ${BT.border}`, borderRadius: 8,
      boxShadow: '0 1px 3px rgba(0,0,0,0.05)', overflow: 'hidden' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', direction: 'rtl', tableLayout: 'fixed' }}>
        <colgroup>
          <col style={{ width: 'auto' }} /><col style={{ width: 70 }} /><col style={{ width: 66 }} /><col style={{ width: 66 }} />
        </colgroup>
        <thead>
          <tr style={{ background: '#F7F8FA', borderBottom: `1px solid ${BT.border}` }}>
            <th style={{ padding: '9px 11px', fontSize: 10, fontWeight: 600, color: BT.g500, textAlign: 'right' }}>סעיף</th>
            <th style={numHead}>התקשרות</th>
            <th style={numHead}>מצטבר</th>
            <th style={numHead}>יתרה</th>
          </tr>
        </thead>
        <tbody>
          {sections.map((sec, si) => {
            const sC = sec.rows.reduce((s, r) => s + r.contract, 0);
            const sP = sec.rows.reduce((s, r) => s + r.paid, 0);
            return (
              <React.Fragment key={si}>
                {/* section header */}
                <tr style={{ background: sec.tint }}>
                  <td colSpan={4} style={{ padding: '6px 11px', fontWeight: 800, fontSize: 12, color: sec.fg }}>{sec.title}</td>
                </tr>
                {sec.rows.map((r, i) => {
                  const rem = r.contract - r.paid;
                  return (
                    <tr key={i} style={{ borderBottom: `1px solid ${BT.g100}` }}>
                      <td style={{ padding: '8px 9px', textAlign: 'right', verticalAlign: 'middle' }}>
                        <div style={{ fontSize: 12.5, fontWeight: 700, color: BT.g950, lineHeight: 1.25 }}>{r.main}</div>
                        {r.sub && <div style={{ fontSize: 11, color: BT.g500, marginTop: 1, whiteSpace: 'nowrap',
                          overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.sub}</div>}
                      </td>
                      <td style={{ ...num, color: BT.g800, fontWeight: 600 }}>{bshort(r.contract)}</td>
                      <td style={{ ...num, color: r.paid ? BT.teal600 : BT.g400, fontWeight: 600 }}>{bshort(r.paid)}</td>
                      <td style={{ ...num, color: rem ? BT.g800 : BT.g400, fontWeight: 600 }}>{bshort(rem)}</td>
                    </tr>
                  );
                })}
                {/* section subtotal */}
                <tr style={{ background: '#F7F8FA', borderBottom: `1px solid ${BT.border}` }}>
                  <td style={{ padding: '8px 11px', fontWeight: 700, fontSize: 11.5, color: sec.fg }}>סה״כ {sec.title}</td>
                  <td style={{ ...num, color: BT.g900, fontWeight: 800 }}>{bshort(sC)}</td>
                  <td style={{ ...num, color: BT.g900, fontWeight: 800 }}>{bshort(sP)}</td>
                  <td style={{ ...num, color: BT.g900, fontWeight: 800 }}>{bshort(sC - sP)}</td>
                </tr>
              </React.Fragment>
            );
          })}
          {/* grand total */}
          <tr style={{ background: '#234F8C' }}>
            <td style={{ padding: '11px', fontWeight: 800, fontSize: 13, color: '#fff', textAlign: 'right' }}>סה״כ כללי</td>
            <td style={{ ...num, color: '#fff', fontWeight: 800 }}>{bshort(gC)}</td>
            <td style={{ ...num, color: '#fff', fontWeight: 800 }}>{bshort(gP)}</td>
            <td style={{ ...num, color: '#fff', fontWeight: 800 }}>{bshort(gC - gP)}</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

function SectionLabel({ children }) {
  return <div style={{ fontSize: 12, fontWeight: 700, color: BT.navy700, letterSpacing: '0.04em',
    margin: '20px 2px 9px' }}>{children}</div>;
}

function BudgetScreen({ platform = 'ios' }) {
  const topPad = platform === 'ios' ? 56 : 12;
  const b = BUDGET;
  const usedPct = Math.round((b.used / b.approved) * 100);
  const consultTotal = b.consultants.reduce((s, r) => s + r.contract, 0);
  const consultPct = (consultTotal / b.contractorEst * 100).toFixed(1) + '%';

  return (
    <div dir="rtl" style={{ height: '100%', display: 'flex', flexDirection: 'column',
      fontFamily: "'Heebo', system-ui, sans-serif", background: BT.page, color: BT.g950,
      WebkitFontSmoothing: 'antialiased' }}>

      {/* App bar */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${BT.border}`, padding: `${topPad}px 8px 9px`,
        flexShrink: 0, display: 'flex', alignItems: 'center' }}>
        <button style={{ width: 40, height: 40, border: 'none', background: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{BIcons.back(BT.navy900)}</button>
        <div style={{ flex: 1, textAlign: 'center', padding: '0 6px' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: BT.g950, lineHeight: 1.2 }}>תקציב הפרויקט</div>
          <div style={{ fontSize: 12.5, color: BT.g950, fontWeight: 700, marginTop: 1 }}>בניית בית ספר רמות</div>
        </div>
        <div style={{ width: 40, flexShrink: 0 }} />
      </div>

      {/* Scroll body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px 22px' }}>
        {/* Metrics */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ display: 'flex', gap: 10 }}>
            <Metric label="אומדן קבלני" value={bils(b.contractorEst)} />
            <Metric label="תקציב שאושר" value={bils(b.approved)} accent={BT.teal600} />
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <Metric label="ניצול תקציבי" value={usedPct + '%'} sub={bils(b.used)} accent={usedPct >= 85 ? '#A06A20' : BT.navy900} />
            <Metric label="אחוז יועצים מאומדן" value={consultPct} sub={bils(consultTotal)} />
          </div>
        </div>

        {/* Budget utilization bar */}
        <div style={{ background: BT.card, border: `1px solid ${BT.border}`, borderRadius: 8,
          boxShadow: '0 1px 3px rgba(0,0,0,0.05)', padding: '13px 15px', marginTop: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
            <span style={{ fontSize: 12.5, color: BT.g500, fontWeight: 500 }}>ניצול מול תקציב שאושר</span>
            <span style={{ fontSize: 12.5, fontWeight: 700, color: BT.g900 }}>{bils(b.used)} / {bils(b.approved)}</span>
          </div>
          <div style={{ height: 8, borderRadius: 4, background: BT.g100, overflow: 'hidden' }}>
            <div style={{ width: usedPct + '%', height: '100%', background: BT.teal600, borderRadius: 4 }} />
          </div>
        </div>

        {/* Budget breakdown — single table, grouped sections */}
        <SectionLabel>פירוט התקציב</SectionLabel>
        <BudgetTable sections={[
          { title: 'יועצים', tint: '#EAF1FA', fg: '#163356', rows: b.consultants },
          { title: 'אגרות',  tint: '#FAF2E6', fg: '#5C3D10', rows: b.fees },
          { title: 'תקורות', tint: '#F0F2F5', fg: '#444444', rows: b.overheads },
        ]} />
      </div>

      {/* Global bottom nav */}
      <div style={{ flexShrink: 0 }}>
        <BNav platform={platform} active="budget" />
      </div>
    </div>
  );
}

Object.assign(window, { BudgetScreen });
