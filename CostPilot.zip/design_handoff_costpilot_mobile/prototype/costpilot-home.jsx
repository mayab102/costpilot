// CostPilot mobile home screen — RTL Hebrew. Shared content rendered inside
// both the iOS and Android device frames. platform: "ios" | "android".

const T = {
  navy900: '#0B1F3A', navy800: '#112D52', navy700: '#1A3D6E',
  navy200: '#C4D6EC', navy100: '#E6EEF7', navy50: '#F2F6FB',
  teal600: '#0E7C6A', teal500: '#129B86', teal200: '#A8E6DB', teal100: '#D4F3EE', teal50: '#EEF9F7',
  page: '#F5F6F8', card: '#FFFFFF', border: '#E2E5EA',
  g950: '#0D0D0D', g800: '#2E2E2E', g700: '#444444', g500: '#767676', g400: '#9A9A9A', g100: '#EFEFEF',
  infoBg: '#EAF1FA', infoFg: '#163356', infoBd: '#D4E4F4',
  warnBg: '#FAF2E6', warnFg: '#5C3D10', warnBd: '#F5E6CC',
  succBg: '#EEF9F7', succFg: '#0C5749', succBd: '#D4F3EE',
  dangBg: '#F8EDED', dangFg: '#5C2020', dangBd: '#F0D8D8',
  // App renders all figures in Heebo (no monospace) — keep numbers consistent with the app.
  mono: "'Heebo', system-ui, sans-serif",
};

// ── Brand logo — pixel-identical to the app sidebar logo ─────────────────────
function CostPilotLogo() {
  return (
    <div style={{ display: 'inline-flex', alignItems: 'flex-end', gap: 5, direction: 'ltr' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 3.5, height: 28 }}>
        <span style={{ display: 'block', width: 6, height: 12, borderRadius: 1.5, background: '#0B1F3A', opacity: 0.35 }} />
        <span style={{ display: 'block', width: 6, height: 20, borderRadius: 1.5, background: '#0B1F3A', opacity: 0.65 }} />
        <span style={{ display: 'block', width: 6, height: 28, borderRadius: 1.5, background: '#0B1F3A' }} />
      </div>
      <div style={{ fontFamily: "'Heebo', sans-serif", fontSize: 21, fontWeight: 700, color: '#0B1F3A',
        whiteSpace: 'nowrap', marginBottom: -2, lineHeight: 1, letterSpacing: '-0.4px' }}>
        Cost<span style={{ fontWeight: 400 }}>Pilot</span>
      </div>
    </div>
  );
}

const fmtILS = n => '₪' + Number(n).toLocaleString('he-IL');

// ── Icons (outline, 1.5px, matching design system) ───────────────────────────
const Ic = {
  bell: (c='#fff') => <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M13.7 21a2 2 0 0 1-3.4 0" stroke={c} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  chevron: (c='#9A9A9A') => <svg width="9" height="16" viewBox="0 0 9 16" fill="none"><path d="M7 1 1 8l6 7" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  doc: (c) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5Z" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/><path d="M14 3v5h5M8.5 13h7M8.5 16.5h5" stroke={c} strokeWidth="1.6" strokeLinecap="round"/></svg>,
  arrowUp: (c) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 19V5M5 12l7-7 7 7" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  send: (c) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M21 3 3 10.5l6.5 2.5L12 19l9-16Z" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/><path d="M9.5 13 21 3" stroke={c} strokeWidth="1.6" strokeLinecap="round"/></svg>,
  home: (c) => <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 11.5 12 4l8 7.5M6 10v9h12v-9" stroke={c} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  folder: (c) => <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M3 7a2 2 0 0 1 2-2h4l2 2.2h6a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z" stroke={c} strokeWidth="1.7" strokeLinejoin="round"/></svg>,
  list: (c) => <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M8 6h12M8 12h12M8 18h12" stroke={c} strokeWidth="1.7" strokeLinecap="round"/><circle cx="4" cy="6" r="1.2" fill={c}/><circle cx="4" cy="12" r="1.2" fill={c}/><circle cx="4" cy="18" r="1.2" fill={c}/></svg>,
  wallet: (c) => <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M3 8a2 2 0 0 1 2-2h13a1 1 0 0 1 1 1v1m0 0H6a3 3 0 0 0-3 3v6a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2V8Z" stroke={c} strokeWidth="1.7" strokeLinejoin="round"/><circle cx="16.5" cy="13.5" r="1.3" fill={c}/></svg>,
  dots: (c) => <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><circle cx="5" cy="12" r="1.6" fill={c}/><circle cx="12" cy="12" r="1.6" fill={c}/><circle cx="19" cy="12" r="1.6" fill={c}/></svg>,
  search: (c) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke={c} strokeWidth="1.7"/><path d="m20 20-3.2-3.2" stroke={c} strokeWidth="1.7" strokeLinecap="round"/></svg>,
  plus: (c='#fff') => <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke={c} strokeWidth="2" strokeLinecap="round"/></svg>,
  clock: (c) => <svg width="13" height="13" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke={c} strokeWidth="1.8"/><path d="M12 7.5V12l3 2" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>,
};

// ── Status badge ─────────────────────────────────────────────────────────────
function StatusBadge({ status }) {
  const map = {
    'פעיל':   { bg: T.teal50,  fg: '#1C4532', dot: '#2E7D56' },
    'תכנון':  { bg: T.warnBg,  fg: T.warnFg,  dot: '#A06A20' },
    'הושלם':  { bg: T.infoBg,  fg: T.infoFg,  dot: '#2A5A8C' },
    'מושהה':  { bg: '#F0F2F5', fg: '#444',    dot: '#9A9A9A' },
  };
  const c = map[status] || map['תכנון'];
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: c.bg, color: c.fg,
      fontSize: 12, fontWeight: 600, padding: '3px 9px', borderRadius: 4, lineHeight: 1 }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: c.dot }} />{status}
    </span>
  );
}

// ── Action item card ─────────────────────────────────────────────────────────
function ActionCard({ item }) {
  const z = item.zone;
  return (
    <div style={{ background: T.card, border: `1px solid ${T.border}`, borderRadius: 8,
      boxShadow: '0 1px 3px rgba(0,0,0,0.05)', overflow: 'hidden', display: 'flex' }}>
      <div style={{ width: 4, background: z.dot, flexShrink: 0 }} />
      <div style={{ flex: 1, padding: '13px 14px' }}>
        {/* Row 1 — project name (primary) + amount */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: 7, background: z.bg, display: 'flex',
            alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{item.icon(z.fg)}</div>
          <div style={{ flex: 1, minWidth: 0, fontSize: 14.5, fontWeight: 700, color: T.g950,
            lineHeight: 1.25, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.project}</div>
          <div style={{ fontFamily: T.mono, fontSize: 14, fontWeight: 600, color: T.g950, flexShrink: 0 }}>{fmtILS(item.amount)}</div>
        </div>

        {/* Row 2 — action on its own line, consultant field below */}
        <div style={{ marginTop: 7, paddingRight: 42 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: z.fg, lineHeight: 1.35 }}>{item.title}</div>
          <div style={{ fontSize: 12.5, color: T.g500, marginTop: 1, lineHeight: 1.35 }}>{item.detail}</div>
        </div>

        {/* Row 3 — waiting */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 11, paddingTop: 10,
          borderTop: `1px solid ${T.g100}` }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap',
            color: item.urgent ? T.dangFg : T.g400 }}>
            {Ic.clock(item.urgent ? '#A03030' : '#9A9A9A')}
            <span style={{ fontSize: 11.5, fontWeight: 600 }}>{'ממתין ' + item.waiting}</span>
          </div>
          <span style={{ fontSize: 12.5, fontWeight: 600, color: T.navy700 }}>פתח</span>
          {Ic.chevron('#C4C4C4')}
        </div>
      </div>
    </div>
  );
}

// ── Project card ─────────────────────────────────────────────────────────────
function ProjectCard({ p }) {
  const pct = Math.round((p.used / p.total) * 100);
  const barColor = pct >= 85 ? '#C47B0A' : T.teal600;
  return (
    <div style={{ background: T.card, border: `1px solid ${T.border}`, borderRadius: 8,
      boxShadow: '0 1px 3px rgba(0,0,0,0.05)', padding: '14px 15px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 15.5, fontWeight: 700, color: T.g950, lineHeight: 1.3 }}>{p.name}</div>
          <div style={{ fontFamily: T.mono, fontSize: 11.5, color: T.g500, marginTop: 3 }}>#{p.num}</div>
        </div>
        <StatusBadge status={p.status} />
      </div>

      <div style={{ marginTop: 13 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
          <span style={{ fontSize: 11.5, color: T.g500, fontWeight: 500 }}>ניצול תקציב</span>
          <span style={{ fontFamily: T.mono, fontSize: 12, fontWeight: 600, color: T.g800 }}>
            {fmtILS(p.used)} <span style={{ color: T.g400 }}>/ {fmtILS(p.total)}</span>
          </span>
        </div>
        <div style={{ height: 6, borderRadius: 3, background: T.g100, overflow: 'hidden' }}>
          <div style={{ width: pct + '%', height: '100%', background: barColor, borderRadius: 3 }} />
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginTop: 13 }}>
        <MiniStat label="יועצים" value={p.consultants} />
        <MiniStat label="חשבונות" value={p.accounts} />
        <MiniStat label="ניצול" value={pct + '%'} accent={pct >= 85} />
      </div>
    </div>
  );
}

function MiniStat({ label, value, accent }) {
  return (
    <div style={{ flex: 1, background: T.navy50, borderRadius: 6, padding: '7px 10px' }}>
      <div style={{ fontFamily: T.mono, fontSize: 15, fontWeight: 700, color: accent ? '#A06A20' : T.navy900, lineHeight: 1.1 }}>{value}</div>
      <div style={{ fontSize: 11, color: T.g500, marginTop: 2 }}>{label}</div>
    </div>
  );
}

// ── Bottom navigation (platform-specific) ────────────────────────────────────
function BottomNav({ platform, active = 'home' }) {
  const tabs = [
    { id: 'home', label: 'בית', icon: Ic.home },
    { id: 'projects', label: 'פרויקטים', icon: Ic.folder },
    { id: 'budget', label: 'תקציב', icon: Ic.wallet },
    { id: 'more', label: 'עוד', icon: Ic.dots },
  ];

  if (platform === 'android') {
    return (
      <div style={{ background: '#FAFCFB', borderTop: `1px solid ${T.border}`, display: 'flex',
        padding: '6px 4px 8px', position: 'relative' }}>
        {tabs.map(t => {
          const on = t.id === active;
          return (
            <div key={t.id} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
              <div style={{ height: 30, width: 58, borderRadius: 15, display: 'flex', alignItems: 'center',
                justifyContent: 'center', background: on ? T.teal100 : 'transparent' }}>
                {t.icon(on ? T.teal600 : T.g500)}
              </div>
              <span style={{ fontSize: 11, fontWeight: on ? 700 : 500, color: on ? T.navy900 : T.g500 }}>{t.label}</span>
            </div>
          );
        })}
      </div>
    );
  }
  // iOS
  return (
    <div style={{ background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(20px)',
      WebkitBackdropFilter: 'blur(20px)', borderTop: `0.5px solid rgba(0,0,0,0.12)`, display: 'flex',
      padding: '8px 4px 6px' }}>
      {tabs.map(t => {
        const on = t.id === active;
        const c = on ? T.teal600 : '#8E8E93';
        return (
          <div key={t.id} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
            {t.icon(c)}
            <span style={{ fontSize: 10.5, fontWeight: on ? 600 : 500, color: c, letterSpacing: 0.1 }}>{t.label}</span>
          </div>
        );
      })}
    </div>
  );
}

// ── Main screen ──────────────────────────────────────────────────────────────
function CostPilotHome({ platform = 'ios' }) {
  const topPad = platform === 'ios' ? 58 : 12; // clear status bar (ios island) — android bar already offset by frame

  const actions = [
    { zone: { bg: T.infoBg, fg: T.infoFg, dot: '#2A5A8C' }, icon: Ic.doc, title: 'ממתין לאישור מנהל פרויקט',
      detail: 'חשבון יועץ קונסטרוקציה', amount: 124500, project: 'בניית בית ספר רמות', projInit: 'ב',
      waiting: '3 ימים', urgent: false },
    { zone: { bg: T.warnBg, fg: T.warnFg, dot: '#A06A20' }, icon: Ic.arrowUp, title: 'ממתין להעברה לאישור מנהל',
      detail: 'הגדלת הסכם אדריכלות', amount: 38000, project: 'מבנה ציבור שכונת הדר', projInit: 'מ',
      waiting: '6 ימים', urgent: true },
    { zone: { bg: T.succBg, fg: T.succFg, dot: '#0C5749' }, icon: Ic.send, title: 'ממתין להעברה לחברה העירונית',
      detail: 'חשבון מאושר אינסטלציה', amount: 92300, project: 'בניית בית ספר רמות', projInit: 'ב',
      waiting: 'יומיים', urgent: false },
  ];

  const projects = [
    { name: 'בניית בית ספר רמות', num: '2024-118', status: 'פעיל', used: 11420000, total: 18400000, consultants: 9, accounts: 14 },
    { name: 'מבנה ציבור שכונת הדר', num: '2023-204', status: 'פעיל', used: 19116000, total: 23600000, consultants: 12, accounts: 27 },
    { name: 'שיפוץ מרכז קהילתי', num: '2024-090', status: 'תכנון', used: 496000, total: 6200000, consultants: 4, accounts: 1 },
  ];

  return (
    <div dir="rtl" style={{ height: '100%', display: 'flex', flexDirection: 'column',
      fontFamily: "'Heebo', system-ui, sans-serif", background: T.page, color: T.g950,
      WebkitFontSmoothing: 'antialiased' }}>

      {/* App bar — white, holds the exact app logo */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${T.border}`, padding: `${topPad}px 16px 11px`,
        flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <CostPilotLogo />
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ position: 'relative', width: 38, height: 38, borderRadius: 8,
            background: T.navy50, border: `1px solid ${T.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {Ic.bell(T.navy900)}
            <span style={{ position: 'absolute', top: 7, left: 8, width: 8, height: 8, borderRadius: '50%',
              background: '#C0392B', border: '1.5px solid #fff' }} />
          </div>
          <div style={{ width: 38, height: 38, borderRadius: '50%', background: T.teal600, color: '#fff',
            fontSize: 15, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>עי</div>
        </div>
      </div>

      {/* Hero — solid navy #0B1F3A (exact app primary) */}
      <div style={{ background: '#0B1F3A', padding: '17px 18px 18px', flexShrink: 0 }}>
        {/* title */}
        <div>
          <div style={{ fontSize: 11, fontWeight: 600, color: T.teal200, letterSpacing: '0.14em' }}>גיליון גלובלי</div>
          <h1 style={{ margin: '5px 0 0', fontSize: 26, fontWeight: 800, color: '#fff', letterSpacing: '-0.01em' }}>לוח בקרה</h1>
          <div style={{ fontSize: 13, color: T.navy200, marginTop: 4 }}>שלום עידן, יש לך 5 משימות הממתינות לטיפול</div>
        </div>

        {/* stat strip */}
        <div style={{ display: 'flex', gap: 9, marginTop: 18 }}>
          {[
            { v: '3', l: 'פרויקטים פעילים' },
            { v: '5', l: 'דורש טיפול', accent: true },
          ].map((s, i) => (
            <div key={i} style={{ flex: 1, background: s.accent ? 'rgba(45,184,159,0.14)' : 'rgba(255,255,255,0.06)',
              border: `1px solid ${s.accent ? 'rgba(45,184,159,0.35)' : 'rgba(255,255,255,0.10)'}`,
              borderRadius: 6, padding: '11px 13px' }}>
              <div style={{ fontFamily: T.mono, fontSize: 21, fontWeight: 800,
                color: s.accent ? '#6CD2BF' : '#fff', lineHeight: 1 }}>{s.v}</div>
              <div style={{ fontSize: 11, color: s.accent ? T.teal200 : T.navy200, marginTop: 6, fontWeight: 500 }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Body — scroll */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '18px 16px 22px' }}>
        {/* Section: action items */}
        <SectionHeader title="דורש טיפול" count="5" link="הצג הכל" />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 11 }}>
          {actions.map((a, i) => <ActionCard key={i} item={a} />)}
        </div>

        {/* Section: projects */}
        <div style={{ marginTop: 24 }}>
          <SectionHeader title="הפרויקטים שלי" count="3" link="הצג הכל" />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 11, marginTop: 11 }}>
            {projects.map((p, i) => <ProjectCard key={i} p={p} />)}
          </div>
        </div>
      </div>

      {/* Bottom nav */}
      <div style={{ flexShrink: 0 }}>
        <BottomNav platform={platform} />
      </div>
    </div>
  );
}

function SectionHeader({ title, count, link }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: T.g950 }}>{title}</h2>
      <span style={{ fontFamily: T.mono, fontSize: 12, fontWeight: 600, color: T.teal600,
        background: T.teal50, borderRadius: 20, padding: '2px 8px', lineHeight: 1.4 }}>{count}</span>
      <div style={{ flex: 1 }} />
      <span style={{ fontSize: 12.5, fontWeight: 600, color: T.navy700 }}>{link}</span>
    </div>
  );
}

Object.assign(window, { CostPilotHome, CostPilotLogo, BottomNav, ProjectCard, StatusBadge, MiniStat, SectionHeader, T, Ic, fmtILS });
