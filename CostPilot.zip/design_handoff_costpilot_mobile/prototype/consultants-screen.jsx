// CostPilot — Project consultants list, opened from the "יועצים" button on a
// project card. Field + consultant name + contact details. No budget data.
const { T: CT, BottomNav: CNav } = window;

const CIcons = {
  back: (c) => <svg width="11" height="19" viewBox="0 0 11 19" fill="none"><path d="M1.5 1.5 9 9.5l-7.5 8" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  search: (c) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke={c} strokeWidth="1.7"/><path d="m20 20-3.2-3.2" stroke={c} strokeWidth="1.7" strokeLinecap="round"/></svg>,
  phone: (c) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6.5 3h3l1.5 4-2 1.5a12 12 0 0 0 4.5 4.5L15 15l4 1.5v3a1.5 1.5 0 0 1-1.6 1.5A15.5 15.5 0 0 1 3 5.6 1.5 1.5 0 0 1 4.5 4l2-1Z" stroke={c} strokeWidth="1.6" strokeLinejoin="round"/></svg>,
  mail: (c) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2" stroke={c} strokeWidth="1.6"/><path d="m4 7 8 6 8-6" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>,
};

const CONSULTANTS = [
  { field: 'אדריכלות',       name: 'משה אדריכלים בע״מ',   phone: '03-5551234', email: 'dana@moshe-arch.co.il' },
  { field: 'קונסטרוקציה',    name: 'ש. לוי מהנדסים בע״מ', phone: '03-6471120', email: 'office@levi-eng.co.il' },
  { field: 'אינסטלציה',      name: 'מערכות מים בע״מ',      phone: '04-8123456', email: 'yossi@mayim-sys.co.il' },
  { field: 'חשמל',           name: 'אלקטרה תכנון',         phone: '03-9988776', email: 'haim@electra-p.co.il' },
  { field: 'מיזוג אוויר',    name: 'קלימה הנדסה',          phone: '09-7654321', email: 'ronen@klima-eng.co.il' },
  { field: 'בטיחות אש',      name: 'שלהבת יועצים',         phone: '02-6543210', email: 'avi@shalhevet.co.il' },
  { field: 'אקוסטיקה',       name: 'אקוסטי בע״מ',          phone: '03-7412589', email: 'tamar@acousti.co.il' },
  { field: 'מעליות',         name: 'עליות יועצים',         phone: '08-9871234', email: 'david@aliyot.co.il' },
  { field: 'פיתוח ונוף',     name: 'גן ונוף אדריכלים',     phone: '04-6112233', email: 'sigal@gannof.co.il' },
  { field: 'תנועה ותחבורה',  name: 'נתיבים תכנון תנועה',   phone: '03-5647890', email: 'eyal@netivim.co.il' },
  { field: 'יועץ קרקע',      name: 'גאולוג ייעוץ בע״מ',    phone: '08-9234567', email: 'info@geolog.co.il' },
  { field: 'מדידות',         name: 'מדידות השרון',         phone: '09-8551122', email: 'office@sharon-survey.co.il' },
];

function ConsultantItem({ c, last, defaultOpen }) {
  const [open, setOpen] = React.useState(!!defaultOpen);
  const contactRow = { display: 'flex', alignItems: 'center', gap: 9, textDecoration: 'none',
    background: CT.navy50, border: `1px solid ${CT.border}`, borderRadius: 6, padding: '9px 11px',
    color: CT.g800 };
  return (
    <div style={{ borderBottom: last ? 'none' : `1px solid ${CT.g100}` }}>
      {/* Header row — tap to expand */}
      <button onClick={() => setOpen(o => !o)} style={{ width: '100%', display: 'flex', alignItems: 'center',
        gap: 10, padding: '12px 14px', background: open ? CT.navy50 : 'none', border: 'none',
        cursor: 'pointer', fontFamily: 'inherit', textAlign: 'right' }}>
        <div style={{ flex: 1, minWidth: 0, fontSize: 14.5, color: CT.g950, lineHeight: 1.3,
          display: 'flex', gap: 10 }}>
          <span style={{ fontWeight: 700, width: 100, flexShrink: 0 }}>{c.field}</span>
          <span style={{ fontWeight: 500, flex: 1, minWidth: 0, whiteSpace: 'nowrap',
            overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.name}</span>
        </div>
        <svg width="9" height="6" viewBox="0 0 14 9" fill="none" style={{ flexShrink: 0,
          transform: open ? 'rotate(180deg)' : 'none', transition: 'transform .18s' }}>
          <path d="M1 1.5 7 7l6-5.5" stroke={CT.g400} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </button>
      {/* Contact details — revealed on tap */}
      {open && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: '2px 14px 13px' }}>
          <a href={`tel:${c.phone}`} style={contactRow}>
            {CIcons.phone(CT.navy700)}
            <span dir="ltr" style={{ flex: 1, fontSize: 13, fontWeight: 600, color: CT.g800, textAlign: 'right' }}>{c.phone}</span>
          </a>
          <a href={`mailto:${c.email}`} style={contactRow}>
            {CIcons.mail(CT.navy700)}
            <span dir="ltr" style={{ flex: 1, minWidth: 0, fontSize: 13, fontWeight: 600, color: CT.g800,
              textAlign: 'right', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.email}</span>
          </a>
        </div>
      )}
    </div>
  );
}

function ConsultantsScreen({ platform = 'ios' }) {
  const topPad = platform === 'ios' ? 56 : 12;

  return (
    <div dir="rtl" style={{ height: '100%', display: 'flex', flexDirection: 'column',
      fontFamily: "'Heebo', system-ui, sans-serif", background: CT.page, color: CT.g950,
      WebkitFontSmoothing: 'antialiased' }}>

      {/* App bar — back + project context */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${CT.border}`, padding: `${topPad}px 8px 9px`,
        flexShrink: 0, display: 'flex', alignItems: 'center' }}>
        <button style={{ width: 40, height: 40, border: 'none', background: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{CIcons.back(CT.navy900)}</button>
        <div style={{ flex: 1, textAlign: 'center', padding: '0 6px' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: CT.g950, lineHeight: 1.2 }}>רשימת יועצים</div>
          <div style={{ fontSize: 12.5, color: CT.g950, fontWeight: 700, marginTop: 1 }}>בניית בית ספר רמות</div>
        </div>
        <div style={{ width: 40, flexShrink: 0 }} />
      </div>

      {/* Search + count */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${CT.border}`, padding: '12px 16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, background: CT.page,
          border: `1px solid ${CT.border}`, borderRadius: 4, padding: '0 12px', height: 42 }}>
          {CIcons.search(CT.g400)}
          <span style={{ flex: 1, fontSize: 14, color: CT.g400 }}>חיפוש יועץ או תחום...</span>
        </div>
        <div style={{ fontSize: 12.5, color: CT.g500, marginTop: 10, fontWeight: 500 }}>{CONSULTANTS.length} יועצים בפרויקט</div>
      </div>

      {/* List — dense */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px 22px' }}>
        <div style={{ background: CT.card, border: `1px solid ${CT.border}`, borderRadius: 8,
          boxShadow: '0 1px 3px rgba(0,0,0,0.05)', overflow: 'hidden' }}>
          {CONSULTANTS.map((c, i) => <ConsultantItem key={i} c={c} defaultOpen={i === 0} last={i === CONSULTANTS.length - 1} />)}
        </div>
      </div>

      {/* Global bottom nav */}
      <div style={{ flexShrink: 0 }}>
        <CNav platform={platform} active="projects" />
      </div>
    </div>
  );
}

Object.assign(window, { ConsultantsScreen });
