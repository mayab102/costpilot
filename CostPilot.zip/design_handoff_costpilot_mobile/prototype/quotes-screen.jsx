// CostPilot — Consultant price quotes ("הצעות מחיר יועצים") for a project.
// Grouped by field. Every quote received + the real approval workflow:
// הצעות → המלצה → מזמין  (stages 1→2→3; approved = client approved everything).
const { T: QT, fmtILS: qils, BottomNav: QNav } = window;

const QIcons = {
  back: (c) => <svg width="11" height="19" viewBox="0 0 11 19" fill="none"><path d="M1.5 1.5 9 9.5l-7.5 8" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  search: (c) => <svg width="17" height="17" viewBox="0 0 20 20" fill="none"><circle cx="9" cy="9" r="6.5" stroke={c} strokeWidth="2"/><path d="M14 14l4 4" stroke={c} strokeWidth="2" strokeLinecap="round"/></svg>,
  check: (c, s = 12) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none"><path d="M5 12.5 10 17 19 7" stroke={c} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg>,
};

// status chip colors
const QSTATUS = {
  'אושר':                 { bg: QT.teal50, fg: '#1C4532', dot: '#2E7D56' },
  'מומלץ':                { bg: '#EAF1FA', fg: '#163356', dot: '#2A5A8C' },
  'ממתין לאישור מזמין':   { bg: '#EEF9F7', fg: '#0C5749', dot: '#129B86' },
  'ממתין להעברה למזמין':  { bg: '#EAF1FA', fg: '#163356', dot: '#2A5A8C' },
  'ממתין להמלצה':         { bg: '#FAF2E6', fg: '#5C3D10', dot: '#A06A20' },
};

// 3-stage pipeline (RTL: first stage on the right)
const STAGE_SHORT = ['הצעות', 'המלצה', 'מזמין'];
const STAGE_STATUS = { 1: 'ממתין להמלצה', 2: 'ממתין להעברה למזמין', 3: 'ממתין לאישור מזמין' };

const QUOTES = [
  { field: 'אדריכלות', stage: 3, approved: true, quotes: [
    { name: 'משה אדריכלים בע״מ', pct: 7.5, amount: 420000, rec: true, approved: true },
    { name: 'סטודיו אורבני', pct: 8.2, amount: 459200 },
    { name: 'אדריכלי נוף ושות׳', pct: 9, amount: 504000 },
  ]},
  { field: 'קונסטרוקציה', stage: 3, approved: true, quotes: [
    { name: 'ש. לוי מהנדסים בע״מ', amount: 276000, rec: true, approved: true },
    { name: 'הנדסת מבנים בע״מ', amount: 298000 },
  ]},
  { field: 'אינסטלציה', stage: 3, quotes: [
    { name: 'מערכות מים בע״מ', amount: 168000, rec: true },
    { name: 'אקווה הנדסה', amount: 175000 },
  ]},
  { field: 'חשמל', stage: 2, quotes: [
    { name: 'אלקטרה תכנון', amount: 145000, rec: true },
    { name: 'וולט הנדסה', amount: 139000 },
  ]},
  { field: 'מיזוג אוויר', stage: 1, quotes: [
    { name: 'קלימה הנדסה', amount: 98000 },
    { name: 'אר־קונדישן בע״מ', amount: 104000 },
  ]},
];

function Chip({ status, small }) {
  const c = QSTATUS[status] || QSTATUS['ממתין להמלצה'];
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: c.bg, color: c.fg,
      fontSize: small ? 11 : 11.5, fontWeight: 600, padding: small ? '2px 8px' : '3px 9px', borderRadius: 4,
      lineHeight: 1.4, whiteSpace: 'nowrap' }}>
      {status === 'אושר'
        ? QIcons.check(c.dot, 11)
        : <span style={{ width: 6, height: 6, borderRadius: '50%', background: c.dot }} />}
      {status}
    </span>
  );
}

function Stepper({ stage, approved }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', padding: '12px 20px 13px',
      borderBottom: `1px solid ${QT.g100}` }}>
      {STAGE_SHORT.map((label, i) => {
        const n = i + 1;
        const done = approved || n < stage, cur = !approved && n === stage;
        const col = done ? QT.teal600 : cur ? QT.navy900 : QT.g300;
        return (
          <React.Fragment key={i}>
            {i > 0 && (
              <div style={{ flex: 1, height: 2, marginTop: 8,
                background: (approved || n <= stage) ? QT.teal600 : QT.g200 }} />
            )}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5, flexShrink: 0, width: 54 }}>
              <div style={{ width: 18, height: 18, borderRadius: '50%', flexShrink: 0,
                background: done ? QT.teal600 : cur ? QT.navy900 : '#fff',
                border: `2px solid ${col}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {done && QIcons.check('#fff', 10)}
                {cur && <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#fff' }} />}
              </div>
              <span style={{ fontSize: 10, fontWeight: cur ? 700 : 500,
                color: (approved || n <= stage) ? QT.g800 : QT.g400, whiteSpace: 'nowrap' }}>{label}</span>
            </div>
          </React.Fragment>
        );
      })}
    </div>
  );
}

function FieldQuotes({ f }) {
  const headStatus = f.approved ? 'אושר' : STAGE_STATUS[f.stage];
  const fc = QSTATUS[headStatus];
  return (
    <div style={{ background: QT.card, border: `1px solid ${QT.border}`, borderRadius: 8,
      boxShadow: '0 1px 3px rgba(0,0,0,0.05)', overflow: 'hidden' }}>
      {/* field header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '11px 14px',
        background: '#F7F8FA', borderBottom: `1px solid ${QT.border}` }}>
        <span style={{ fontSize: 14, fontWeight: 800, color: QT.g950 }}>{f.field}</span>
        <span style={{ fontSize: 11.5, color: QT.g400, fontWeight: 500, whiteSpace: 'nowrap', flexShrink: 0 }}>· {f.quotes.length} הצעות</span>
        <div style={{ flex: 1 }} />
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: fc.bg, color: fc.fg,
          fontSize: 11.5, fontWeight: 600, padding: '3px 9px', borderRadius: 4, lineHeight: 1.4, whiteSpace: 'nowrap' }}>
          {headStatus === 'אושר'
            ? QIcons.check(fc.dot, 11)
            : <span style={{ width: 6, height: 6, borderRadius: '50%', background: fc.dot }} />}
          {headStatus}
        </span>
      </div>

      {/* approval pipeline */}
      <Stepper stage={f.stage} approved={f.approved} />

      {/* quote rows — fixed columns so all amounts align (RTL) */}
      {f.quotes.map((q, i) => {
        const rowChip = q.approved ? 'אושר' : q.rec ? 'מומלץ' : null;
        const lead = q.approved || q.rec;
        return (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 38px 80px 62px', alignItems: 'center',
            gap: 8, padding: '10px 14px',
            background: q.approved ? QT.teal50 : q.rec ? QT.navy50 : '#fff',
            borderBottom: i === f.quotes.length - 1 ? 'none' : `1px solid ${QT.g100}` }}>
            <div style={{ minWidth: 0, fontSize: 13, fontWeight: lead ? 700 : 500,
              color: lead ? QT.g900 : QT.g500, textAlign: 'right', whiteSpace: 'nowrap',
              overflow: 'hidden', textOverflow: 'ellipsis' }}>{q.name}</div>
            <div style={{ textAlign: 'right', whiteSpace: 'nowrap', fontSize: 12, fontWeight: 700,
              color: lead ? QT.g700 : QT.g500 }}>{q.pct != null ? q.pct + '%' : ''}</div>
            <div style={{ textAlign: 'right', whiteSpace: 'nowrap', fontSize: 12.5, fontWeight: 700,
              color: lead ? QT.g950 : QT.g500 }}>{qils(q.amount)}</div>
            <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
              {rowChip && <Chip status={rowChip} small />}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function QuotesScreen({ platform = 'ios' }) {
  const topPad = platform === 'ios' ? 56 : 12;
  const [query, setQuery] = React.useState('');
  const qq = query.trim();
  const list = qq ? QUOTES.filter(f => f.field.includes(qq) || f.quotes.some(x => x.name.includes(qq))) : QUOTES;
  return (
    <div dir="rtl" style={{ height: '100%', display: 'flex', flexDirection: 'column',
      fontFamily: "'Heebo', system-ui, sans-serif", background: QT.page, color: QT.g950,
      WebkitFontSmoothing: 'antialiased' }}>

      {/* App bar */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${QT.border}`, padding: `${topPad}px 8px 9px`,
        flexShrink: 0, display: 'flex', alignItems: 'center' }}>
        <button style={{ width: 40, height: 40, border: 'none', background: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{QIcons.back(QT.navy900)}</button>
        <div style={{ flex: 1, textAlign: 'center', padding: '0 6px' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: QT.g950, lineHeight: 1.2 }}>הצעות מחיר יועצים</div>
          <div style={{ fontSize: 12.5, color: QT.g950, fontWeight: 700, marginTop: 1 }}>בניית בית ספר רמות</div>
        </div>
        <div style={{ width: 40, flexShrink: 0 }} />
      </div>

      {/* Search */}
      <div style={{ background: '#fff', borderBottom: `1px solid ${QT.border}`, padding: '10px 16px 12px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, background: '#F0F2F5',
          borderRadius: 9, padding: '0 12px', height: 40 }}>
          {QIcons.search(QT.g400)}
          <input value={query} onChange={e => setQuery(e.target.value)}
            placeholder="חיפוש לפי תחום או שם יועץ"
            style={{ flex: 1, border: 'none', outline: 'none', background: 'transparent',
              fontFamily: 'inherit', fontSize: 14, color: QT.g950, textAlign: 'right', padding: 0 }} />
          {query && (
            <button onClick={() => setQuery('')} aria-label="נקה"
              style={{ border: 'none', background: 'none', cursor: 'pointer', color: QT.g400,
                fontSize: 18, lineHeight: 1, padding: 0, flexShrink: 0 }}>×</button>
          )}
        </div>
      </div>

      {/* List */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px 22px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {list.map((f, i) => <FieldQuotes key={f.field} f={f} />)}
          {list.length === 0 && (
            <div style={{ textAlign: 'center', color: QT.g400, fontSize: 14, padding: '40px 0' }}>
              לא נמצאו תוצאות עבור “{qq}”
            </div>
          )}
        </div>
      </div>

      {/* Global bottom nav */}
      <div style={{ flexShrink: 0 }}>
        <QNav platform={platform} active="projects" />
      </div>
    </div>
  );
}

Object.assign(window, { QuotesScreen });
