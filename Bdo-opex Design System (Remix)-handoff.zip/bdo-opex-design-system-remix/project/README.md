# Bdo-opex Design System

## Overview

**Bdo-opex** is a professional project management and financial data platform designed for enterprise use. The interface is a data-heavy application prioritizing clarity, structure, and efficiency. The product is built for RTL (right-to-left) markets, supporting Arabic as the primary language with full RTL layout directionality.

No external codebase or Figma links were provided. This design system was created from a written product brief.

---

## Products

| Product | Path | Description |
|---|---|---|
| Dashboard App | `ui_kits/app/` | Core data-heavy RTL application with dashboards, tables, forms, budgets, and reports |

---

## CONTENT FUNDAMENTALS

### Language & Tone
- **Primary language:** Arabic (RTL). All layouts default to right-to-left.
- **Secondary language:** Latin script (English) for labels, codes, or international values.
- **Tone:** Professional, calm, direct, and informative. No casual language or humor.
- **Voice:** Third-person or system-voice for notifications; second-person ("أنت / You") for instructions.
- **Casing:** Title case for section headers and navigation; sentence case for body text and descriptions.
- **Emoji:** Never used. The product is enterprise-grade and emoji would undermine professionalism.
- **Numbers:** Formatted with locale-appropriate separators. Financial figures always show currency symbol/code.
- **Dates:** ISO-style or localized Arabic calendar dates depending on context.

### Copy Patterns
- Labels are concise: "الميزانية" not "إجمالي الميزانية المخصصة لهذا المشروع"
- Status messages are factual: "تم الحفظ" / "Saved" — no exclamation marks.
- Errors identify the problem and the remedy: "الحقل مطلوب — يرجى إدخال القيمة"
- Empty states explain what belongs there, not that it's empty.

---

## VISUAL FOUNDATIONS

### Color System
See `colors_and_type.css` for all tokens.

- **Primary:** Deep navy `#0B1F3A` — used for primary actions, active states, headers.
- **Accent:** Professional teal `#0E7C6A` — used for highlights, selected rows, key metrics.
- **Neutral scale:** 9-step gray scale from `#F7F8FA` (bg) to `#0D0D0D` (near-black).
- **Semantic:** Success green `#1A7F50`, Warning amber `#C47B0A`, Danger red `#C0392B`, Info blue `#1565C0`.
- **Background:** `#F5F6F8` page bg; `#FFFFFF` card bg; `#EFF1F5` subtle bg for alternating rows.
- Color roles are strict — accent color never appears as a background outside highlighted states.

### Typography
- **Primary font:** Cairo (Google Fonts) — geometric Arabic/Latin, clean at all weights, excellent RTL.
- **Monospace:** IBM Plex Mono — for financial codes, IDs, numeric data columns.
- **Type scale:** 11px / 12px / 13px / 14px / 16px / 18px / 22px / 28px / 36px
- **Weights used:** 400 (body), 500 (label/caption), 600 (subheading), 700 (heading).
- **Line height:** 1.5 for body; 1.2 for headings; 1.0 for single-line labels/buttons.
- **Letter spacing:** -0.01em for headings; 0.02em for uppercase labels/caps.
- **Text direction:** `dir="rtl"`, `text-align: right` globally.

### Spacing
- Base unit: 4px. Scale: 4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96.
- Component padding: inputs/buttons use 8px vertical, 16px horizontal.
- Section spacing: 24px between components; 48px between major sections.

### Backgrounds
- No gradient backgrounds on page level.
- Cards: white with `1px solid #E2E5EA` border and very subtle shadow.
- No textures, patterns, or illustrations in the data app.
- Full-bleed color only on top navigation bar (navy `#0B1F3A`).

### Borders & Corners
- Corner radius: **4px** on all interactive elements (buttons, inputs, cards, badges).
- **2px** for table cells and compact UI.
- **0px** for table rows, dividers, nav items.
- Borders: `1px solid #E2E5EA` (default); `1px solid #0B1F3A` (focused); `1px solid #C0392B` (error).

### Shadows / Elevation
- Level 0: No shadow (flat, in-page items).
- Level 1: `0 1px 3px rgba(0,0,0,0.07)` — cards, dropdowns.
- Level 2: `0 4px 12px rgba(0,0,0,0.10)` — modals, popovers.
- Level 3: `0 8px 24px rgba(0,0,0,0.14)` — dialogs, top-level overlays.

### Animation
- Easing: `cubic-bezier(0.2, 0, 0, 1)` — smooth deceleration (Material standard).
- Duration: 150ms for micro-interactions (hover, focus); 250ms for panel expand/collapse; 350ms for modals.
- No bounce, spring, or playful easing — professional data environment.
- Fade + translate (4px up) for dropdown/popover entry.

### Hover / Press States
- Buttons: hover darkens bg by ~8%; press slightly scales down `scale(0.98)`.
- Rows: hover bg `#EFF1F5`; selected bg `#E1EDF8` with left (in RTL: right) accent border.
- Links: underline on hover only; no color change.
- Icons: opacity 0.7 on hover.

### Cards
- White background, `border: 1px solid #E2E5EA`, `border-radius: 4px`, Level 1 shadow.
- Padding: 24px.
- No colored borders or accent strips — color comes from content, not chrome.

### Imagery
- No decorative imagery in the application.
- Charts and data visualizations are the primary "imagery".
- Color palette for charts: navy, teal, slate, amber, red — sequential/diverging scales.

### Use of Transparency & Blur
- Backdrop blur only on modal overlay: `backdrop-filter: blur(4px)` on scrim.
- No frosted-glass or translucency in the UI.

---

## ICONOGRAPHY

See `assets/icons/` for the full icon set.

### Style Direction
- **Style:** Outline / linear, 1.5px stroke, rounded joins, square caps.
- **Grid:** 24×24px primary; 20×20px compact; 16×16px dense/inline.
- **Corner radius on icon shapes:** 2px on rectangles; circles remain circular.
- **Visual weight:** Uniform — no icon heavier or lighter than another.
- Icons built as inline SVGs. No icon font or external CDN (all custom to match brand).

### Icon Set Coverage
Documented in `assets/icons/` — covers: navigation, actions (add, edit, delete, save), search, filter, sort, status (success, warning, error, info), entities (project, budget, report, user, settings, calendar, alert, chart).

### RTL Considerations
- Directional icons (arrows, chevrons, back/forward) are mirrored for RTL.
- Non-directional icons (settings gear, search, status) are not mirrored.
- Icon spacing from text: 8px gap in RTL flex rows.

---

## FILE INDEX

| File | Description |
|---|---|
| `README.md` | This file — system overview and documentation |
| `colors_and_type.css` | All CSS custom properties: colors, type, spacing, shadows |
| `assets/icons/` | Custom SVG icon set (24px outline linear) |
| `assets/logo/` | Brand logo files |
| `preview/` | Design System tab cards (colors, type, spacing, components) |
| `ui_kits/app/` | RTL dashboard app UI kit |
| `SKILL.md` | Agent skill definition for Claude Code |
