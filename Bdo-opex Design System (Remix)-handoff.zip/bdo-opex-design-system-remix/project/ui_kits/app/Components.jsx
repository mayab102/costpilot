// Bdo-opex UI Kit — Shared Components (Hebrew RTL)
const { useState } = React;

const Icon = ({ name, size = 16, color = "currentColor", style: s }) => {
  const icons = {
    dashboard: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
    project: <><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></>,
    budget: <><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2"/><line x1="12" y1="12" x2="12" y2="16"/><line x1="10" y1="14" x2="14" y2="14"/></>,
    report: <><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></>,
    chart: <><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></>,
    alert: <><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></>,
    add: <><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>,
    edit: <><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></>,
    trash: <><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/></>,
    search: <><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></>,
    filter: <><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></>,
    download: <><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></>,
    chevronDown: <><polyline points="6 9 12 15 18 9"/></>,
    chevronRight: <><polyline points="9 18 15 12 9 6"/></>,
    chevronLeft: <><polyline points="15 18 9 12 15 6"/></>,
    warning: <><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></>,
    check: <><polyline points="20 6 9 17 4 12"/></>,
    info: <><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>,
    barChart: <><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></>,
    currency: <><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></>,
    home: <><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"
      style={{ flexShrink: 0, ...s }}>
      {icons[name]}
    </svg>
  );
};

const Badge = ({ variant = "neutral", children }) => {
  const variants = {
    success: { bg: "#EDFAF3", color: "#0F4A2E" },
    warning: { bg: "#FFFAEE", color: "#6B4200" },
    danger:  { bg: "#FEF2F1", color: "#6B1515" },
    info:    { bg: "#EAF2FD", color: "#0B3060" },
    neutral: { bg: "#EFEFEF", color: "#444444" },
    primary: { bg: "#E6EEF7", color: "#112D52" },
  };
  const v = variants[variant] || variants.neutral;
  const dots = { success:"#1A7F50", warning:"#C47B0A", danger:"#C0392B", info:"#1565C0", neutral:"#9a9a9a", primary:"#2E64AD" };
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:5, height:20, padding:"0 8px",
      borderRadius:4, fontSize:11, fontWeight:600, background:v.bg, color:v.color, whiteSpace:"nowrap" }}>
      <span style={{ width:6, height:6, borderRadius:"50%", background:dots[variant], flexShrink:0 }}/>
      {children}
    </span>
  );
};

const Btn = ({ variant="primary", size="md", icon, children, onClick, disabled }) => {
  const sizes = { sm:{h:28,px:12,fs:12}, md:{h:36,px:16,fs:13}, lg:{h:44,px:20,fs:14} };
  const variants = {
    primary: { bg:"#0B1F3A", color:"#fff", border:"1px solid #0B1F3A", hoverBg:"#112D52" },
    accent:  { bg:"#0E7C6A", color:"#fff", border:"1px solid #0E7C6A", hoverBg:"#0E6B5B" },
    outline: { bg:"transparent", color:"#0B1F3A", border:"1px solid #0B1F3A", hoverBg:"#E6EEF7" },
    ghost:   { bg:"transparent", color:"#444", border:"1px solid #e2e5ea", hoverBg:"#f7f8fa" },
    danger:  { bg:"#A03030", color:"#fff", border:"1px solid #A03030", hoverBg:"#5C2020" },
  };
  const sz = sizes[size];
  const vr = variants[variant] || variants.primary;
  const [hover, setHover] = useState(false);
  return (
    <button disabled={disabled} onClick={onClick}
      onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
      style={{ display:"inline-flex", alignItems:"center", justifyContent:"center", gap:6,
        height:sz.h, padding:`0 ${sz.px}px`, borderRadius:4, fontFamily:"Heebo, sans-serif",
        fontSize:sz.fs, fontWeight:600, cursor:disabled?"not-allowed":"pointer",
        border:vr.border||"none", background:disabled?"#EFEFEF":hover?vr.hoverBg:vr.bg,
        color:disabled?"#9a9a9a":vr.color, whiteSpace:"nowrap",
        transition:"background 150ms, transform 150ms",
        transform:hover&&!disabled?"scale(0.99)":"scale(1)" }}>
      {icon && <Icon name={icon} size={sz.fs+1}/>}
      {children}
    </button>
  );
};

const Input = ({ label, placeholder, value, onChange, error, icon, type="text" }) => {
  const [focus, setFocus] = useState(false);
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
      {label && <label style={{ fontSize:12, fontWeight:500, color:"#444" }}>{label}</label>}
      <div style={{ position:"relative" }}>
        {icon && <span style={{ position:"absolute", right:10, top:"50%", transform:"translateY(-50%)", color:"#9a9a9a", display:"flex" }}>
          <Icon name={icon} size={14}/>
        </span>}
        <input type={type} value={value} onChange={onChange} placeholder={placeholder}
          onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
          style={{ width:"100%", height:36, padding:`0 ${icon?34:12}px 0 12px`, borderRadius:4,
            fontFamily:"Heebo, sans-serif", fontSize:14, color:"#1a1a1a", direction:"rtl", textAlign:"right",
            border:`1px solid ${error?"#C0392B":focus?"#0B1F3A":"#E2E5EA"}`,
            boxShadow:focus?(error?"0 0 0 3px rgba(192,57,43,0.1)":"0 0 0 3px rgba(11,31,58,0.08)"):"none",
            background:"#fff", outline:"none" }}/>
      </div>
      {error && <span style={{ fontSize:11, color:"#C0392B" }}>{error}</span>}
    </div>
  );
};

const MetricCard = ({ label, value, delta, deltaType="up", icon }) => (
  <div style={{ background:"#fff", border:"1px solid #e2e5ea", borderRadius:4,
    padding:"16px 20px", boxShadow:"0 1px 3px rgba(0,0,0,0.07)", flex:1, minWidth:0 }}>
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
      <div style={{ fontSize:11, color:"#767676", fontWeight:500 }}>{label}</div>
      {icon && <div style={{ color:"#9a9a9a" }}><Icon name={icon} size={16}/></div>}
    </div>
    <div style={{ fontSize:24, fontWeight:700, color:"#0d0d0d", lineHeight:1, marginBottom:6, fontFamily:"'IBM Plex Mono', monospace" }}>{value}</div>
    {delta && <div style={{ fontSize:11, fontWeight:600, color:deltaType==="up"?"#1A7F50":"#C0392B" }}>
      {deltaType==="up"?"↑":"↓"} {delta}
    </div>}
  </div>
);

const ProgressBar = ({ label, value, max=100, color="#0B1F3A" }) => {
  const pct = Math.min((value/max)*100, 100);
  const over = value > max;
  return (
    <div style={{ display:"flex", alignItems:"center", gap:12 }}>
      <div style={{ fontSize:12, color:"#444", minWidth:130, textAlign:"right" }}>{label}</div>
      <div style={{ flex:1, height:6, background:"#e2e5ea", borderRadius:3, overflow:"hidden" }}>
        <div style={{ width:`${pct}%`, height:"100%", background:over?"#C0392B":color, borderRadius:3 }}/>
      </div>
      <div style={{ fontSize:11, color:over?"#C0392B":"#767676", minWidth:38, textAlign:"left",
        fontFamily:"'IBM Plex Mono', monospace", direction:"ltr" }}>{value}%</div>
    </div>
  );
};

const DataTable = ({ columns, rows, onRowClick, selectedId }) => (
  <div style={{ background:"#fff", border:"1px solid #e2e5ea", borderRadius:4,
    boxShadow:"0 1px 3px rgba(0,0,0,0.07)", overflow:"hidden" }}>
    <table style={{ width:"100%", borderCollapse:"collapse" }}>
      <thead>
        <tr>
          {columns.map(col => (
            <th key={col.key} style={{ background:"#F7F8FA", padding:"0 16px", height:36,
              fontSize:11, fontWeight:600, textTransform:"uppercase", letterSpacing:"0.04em",
              color:"#767676", borderBottom:"1px solid #e2e5ea", textAlign:"right",
              whiteSpace:"nowrap" }}>{col.label}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, i) => (
          <tr key={row.id||i} onClick={()=>onRowClick&&onRowClick(row)}
            style={{ cursor:onRowClick?"pointer":"default",
              background:selectedId===row.id?"#E1EDF8":"transparent" }}>
            {columns.map(col => (
              <td key={col.key} style={{ padding:"0 16px", height:40,
                color:col.mono?"#0d0d0d":"#1a1a1a",
                fontFamily:col.mono?"'IBM Plex Mono', monospace":"inherit",
                fontSize:col.mono?12:13,
                borderBottom:i<rows.length-1?"1px solid #f0f1f4":"none",
                textAlign:"right" }}
                onMouseEnter={e=>{if(selectedId!==row.id)e.currentTarget.parentElement.style.background="#EFF1F5"}}
                onMouseLeave={e=>{if(selectedId!==row.id)e.currentTarget.parentElement.style.background="transparent"}}>
                {col.render ? col.render(row[col.key], row) : row[col.key]}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

const Sidebar = ({ active, onNav }) => {
  const navItems = [
    { id:"dashboard", label:"לוח בקרה",    icon:"dashboard" },
    { id:"projects",  label:"פרויקטים",    icon:"project" },
    { id:"budgets",   label:"תקציבים",     icon:"budget" },
    { id:"reports",   label:"דוחות",       icon:"report" },
    { id:"analytics", label:"אנליטיקה",    icon:"chart" },
  ];
  const bottom = [
    { id:"settings", label:"הגדרות",  icon:"settings" },
    { id:"alerts",   label:"התראות",  icon:"alert" },
  ];
  return (
    <div style={{ width:220, background:"#0B1F3A", display:"flex", flexDirection:"column", height:"100%", flexShrink:0 }}>
      <div style={{ padding:"16px 20px", borderBottom:"1px solid rgba(255,255,255,0.08)" }}>
        <div style={{ display:"flex", alignItems:"flex-end", gap:10, direction:"ltr" }}>
          <div style={{ display:"flex", gap:3, alignItems:"flex-end" }}>
            <div style={{ width:6, height:13, background:"#fff", borderRadius:1.5 }}/>
            <div style={{ width:6, height:20, background:"#fff", borderRadius:1.5 }}/>
            <div style={{ width:6, height:28, background:"#fff", borderRadius:1.5 }}/>
          </div>
          <div style={{ fontSize:18, fontWeight:700, color:"#fff", lineHeight:1, letterSpacing:"-0.3px", fontFamily:"Heebo, sans-serif", paddingBottom:1 }}>
            Cost<span style={{ fontWeight:400, color:"rgba(255,255,255,0.75)" }}>Pilot</span>
          </div>
        </div>
      </div>
      <nav style={{ flex:1, padding:"12px 0", overflowY:"auto" }}>
        <div style={{ padding:"0 12px", marginBottom:4 }}>
          <div style={{ fontSize:10, fontWeight:600, textTransform:"uppercase", letterSpacing:"0.06em",
            color:"rgba(255,255,255,0.3)", padding:"8px 8px 4px" }}>תפריט ראשי</div>
        </div>
        {navItems.map(item => (
          <button key={item.id} onClick={()=>onNav(item.id)}
            style={{ display:"flex", alignItems:"center", gap:10, width:"100%", padding:"9px 20px",
              background:active===item.id?"rgba(255,255,255,0.1)":"transparent",
              borderRight:active===item.id?"2px solid #0E7C6A":"2px solid transparent",
              border:"none", cursor:"pointer", textAlign:"right", direction:"rtl",
              color:active===item.id?"#fff":"rgba(255,255,255,0.6)",
              fontSize:13, fontFamily:"Heebo, sans-serif", fontWeight:active===item.id?600:400,
              transition:"all 150ms" }}>
            <Icon name={item.icon} size={16} color={active===item.id?"#fff":"rgba(255,255,255,0.5)"}/>
            {item.label}
          </button>
        ))}
      </nav>
      <div style={{ borderTop:"1px solid rgba(255,255,255,0.08)", padding:"8px 0" }}>
        {bottom.map(item => (
          <button key={item.id} onClick={()=>onNav(item.id)}
            style={{ display:"flex", alignItems:"center", gap:10, width:"100%", padding:"9px 20px",
              background:"transparent", border:"none", cursor:"pointer", textAlign:"right",
              direction:"rtl", color:"rgba(255,255,255,0.5)", fontSize:13,
              fontFamily:"Heebo, sans-serif", transition:"color 150ms" }}
            onMouseEnter={e=>e.currentTarget.style.color="#fff"}
            onMouseLeave={e=>e.currentTarget.style.color="rgba(255,255,255,0.5)"}>
            <Icon name={item.icon} size={16} color="currentColor"/>
            {item.label}
          </button>
        ))}
        <div style={{ margin:"8px 20px 4px", padding:"10px 0",
          borderTop:"1px solid rgba(255,255,255,0.08)", display:"flex", alignItems:"center", gap:8 }}>
          <div style={{ width:32, height:32, borderRadius:"50%", background:"#1A3D6E",
            display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
            <Icon name="user" size={14} color="rgba(255,255,255,0.7)"/>
          </div>
          <div>
            <div style={{ fontSize:12, fontWeight:600, color:"#fff" }}>יוסי כהן</div>
            <div style={{ fontSize:10, color:"rgba(255,255,255,0.4)" }}>מנהל פרויקטים</div>
          </div>
        </div>
      </div>
    </div>
  );
};

const TopBar = ({ title, subtitle, actions }) => (
  <div style={{ background:"#fff", borderBottom:"1px solid #e2e5ea", padding:"0 24px",
    height:56, display:"flex", alignItems:"center", justifyContent:"space-between", flexShrink:0 }}>
    <div style={{ display:"flex", gap:8 }}>{actions}</div>
    <div style={{ textAlign:"right" }}>
      <div style={{ fontSize:16, fontWeight:700, color:"#0d0d0d" }}>{title}</div>
      {subtitle && <div style={{ fontSize:12, color:"#767676", marginTop:1 }}>{subtitle}</div>}
    </div>
  </div>
);

const Card = ({ title, action, children, style: s }) => (
  <div style={{ background:"#fff", border:"1px solid #e2e5ea", borderRadius:4,
    boxShadow:"0 1px 3px rgba(0,0,0,0.07)", ...s }}>
    {title && (
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between",
        padding:"14px 20px", borderBottom:"1px solid #f0f1f4" }}>
        <div>{action}</div>
        <div style={{ fontSize:14, fontWeight:600, color:"#0d0d0d" }}>{title}</div>
      </div>
    )}
    <div style={{ padding:20 }}>{children}</div>
  </div>
);

Object.assign(window, { Icon, Badge, Btn, Input, MetricCard, ProgressBar, DataTable, Sidebar, TopBar, Card });
