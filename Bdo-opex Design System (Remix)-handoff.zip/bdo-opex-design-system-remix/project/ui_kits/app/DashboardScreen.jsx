// Bdo-opex — Dashboard Screen (Hebrew)
const { useState } = React;

const PROJECTS = [
  { id:1, code:"PRJ-2024-001", name:"פיתוח תשתית דיגיטלית",      budget:2500000, spent:1820000, status:"success", statusLabel:"פעיל",       manager:"יוסי כהן" },
  { id:2, code:"PRJ-2024-002", name:"שדרוג מערכת רכש",           budget:850000,  spent:850000,  status:"neutral", statusLabel:"הושלם",      manager:"שרה לוי" },
  { id:3, code:"PRJ-2024-003", name:"תוכנית יעילות תפעולית",     budget:1200000, spent:430000,  status:"warning", statusLabel:"בבדיקה",     manager:"דוד מזרחי" },
  { id:4, code:"PRJ-2024-004", name:"פרויקט טרנספורמציה פיננסית",budget:3100000, spent:120000,  status:"info",    statusLabel:"חדש",        manager:"מיכל שפירא" },
  { id:5, code:"PRJ-2024-005", name:"סקירת מערכות פנימיות",      budget:600000,  spent:680000,  status:"danger",  statusLabel:"חריגת תקציב", manager:"אבי גולן" },
];

const fmt = n => "₪ " + n.toLocaleString("he-IL");
const pct = (s,b) => Math.round((s/b)*100);

const Sparkline = ({ values, color="#0B1F3A" }) => {
  const w=120, h=36, pad=2;
  const max=Math.max(...values), min=Math.min(...values), range=max-min||1;
  const pts = values.map((v,i)=>{
    const x = pad + (i/(values.length-1))*(w-pad*2);
    const y = pad + (1-(v-min)/range)*(h-pad*2);
    return `${x},${y}`;
  }).join(" ");
  const last = pts.split(" ").pop().split(",");
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{display:"block"}}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx={last[0]} cy={last[1]} r="3" fill={color}/>
    </svg>
  );
};

const DashboardScreen = ({ onNav }) => {
  const [selectedRow, setSelectedRow] = useState(1);

  const columns = [
    { key:"code",    label:"קוד",          mono:true },
    { key:"name",    label:"שם הפרויקט" },
    { key:"budget",  label:"תקציב",        mono:true, render:v=>fmt(v) },
    { key:"spent",   label:"בוצע",         mono:true, render:v=>fmt(v) },
    { key:"pct",     label:"ניצול", render:(_,r)=>{
      const p=pct(r.spent,r.budget);
      return <div style={{display:"flex",alignItems:"center",gap:8,justifyContent:"flex-end"}}>
        <span style={{fontSize:11,fontFamily:"'IBM Plex Mono',monospace",color:p>100?"#C0392B":"#444",minWidth:32}}>{p}%</span>
        <div style={{width:60,height:5,background:"#e2e5ea",borderRadius:3,overflow:"hidden"}}>
          <div style={{width:`${Math.min(p,100)}%`,height:"100%",background:p>100?"#C0392B":p>80?"#1A7F50":"#0B1F3A",borderRadius:3}}/>
        </div>
      </div>;
    }},
    { key:"status",  label:"סטטוס",  render:(_,r)=><Badge variant={r.status}>{r.statusLabel}</Badge> },
    { key:"manager", label:"מנהל" },
  ];

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:"#F5F6F8",direction:"rtl"}}>
      <TopBar title="לוח בקרה" subtitle="סקירה כללית של פרויקטים ותקציבים"
        actions={<>
          <Btn variant="ghost" size="sm" icon="download">ייצוא</Btn>
          <Btn variant="primary" size="sm" icon="add">פרויקט חדש</Btn>
        </>}/>
      <div style={{flex:1,overflowY:"auto",padding:24,display:"flex",flexDirection:"column",gap:20}}>
        <div style={{display:"flex",gap:16}}>
          <MetricCard label="סך הפרויקטים"    value="142"       delta="12 החודש"        deltaType="up"   icon="project"/>
          <MetricCard label="סך התקציבים"     value="₪ 48.2M"  delta="8.4%"            deltaType="up"   icon="currency"/>
          <MetricCard label="אחוז השלמה"      value="76%"       delta="3% מתחת ליעד"   deltaType="down" icon="chart"/>
          <MetricCard label="פרויקטים באיחור" value="7"         delta="2 השבוע"         deltaType="down" icon="warning"/>
        </div>

        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
          <Card title="הוצאות חודשיות" action={<Btn variant="ghost" size="sm">פרטים</Btn>}>
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              <Sparkline values={[1.2,1.8,1.4,2.1,1.9,2.8,2.3,3.1,2.7,3.4,2.9,3.8]} color="#0B1F3A"/>
              <div style={{display:"flex",justifyContent:"space-between",marginTop:4}}>
                <div style={{fontSize:11,color:"#9a9a9a"}}>ינואר</div>
                <div style={{fontSize:11,color:"#9a9a9a"}}>דצמבר</div>
              </div>
            </div>
            <div style={{marginTop:16,display:"flex",flexDirection:"column",gap:8}}>
              <ProgressBar label="תשתית דיגיטלית"       value={72}/>
              <ProgressBar label="טרנספורמציה פיננסית"  value={38} color="#0E7C6A"/>
              <ProgressBar label="סקירת מערכות"         value={113}/>
            </div>
          </Card>

          <Card title="התפלגות סטטוסים" action={<Btn variant="ghost" size="sm">סינון</Btn>}>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              {[
                {label:"פרויקטים פעילים",    count:89, pct:63, color:"#0B1F3A"},
                {label:"בבדיקה",             count:24, pct:17, color:"#C47B0A"},
                {label:"הושלמו",             count:22, pct:15, color:"#1A7F50"},
                {label:"חריגת תקציב",        count:7,  pct:5,  color:"#C0392B"},
              ].map(s=>(
                <div key={s.label} style={{display:"flex",alignItems:"center",gap:10}}>
                  <div style={{width:34,fontSize:11,fontWeight:600,color:s.color,fontFamily:"'IBM Plex Mono',monospace",textAlign:"left",direction:"ltr"}}>{s.count}</div>
                  <div style={{flex:1,height:6,background:"#e2e5ea",borderRadius:3,overflow:"hidden"}}>
                    <div style={{width:`${s.pct}%`,height:"100%",background:s.color,borderRadius:3}}/>
                  </div>
                  <div style={{fontSize:12,color:"#444",minWidth:110,textAlign:"right"}}>{s.label}</div>
                </div>
              ))}
            </div>
            <div style={{marginTop:20,paddingTop:16,borderTop:"1px solid #f0f1f4"}}>
              <div style={{fontSize:11,fontWeight:600,textTransform:"uppercase",letterSpacing:"0.04em",color:"#9a9a9a",marginBottom:10}}>התראות אחרונות</div>
              {[
                {msg:"פרויקט PRJ-2024-005 חרג מהתקציב ב-13%",    type:"danger"},
                {msg:"מועד אספקה של PRJ-2024-003 בעוד 5 ימים",   type:"warning"},
                {msg:"התקציב של PRJ-2024-004 אושר",              type:"success"},
              ].map((a,i)=>(
                <div key={i} style={{display:"flex",alignItems:"flex-start",gap:8,marginBottom:8}}>
                  <Icon name={a.type==="danger"?"warning":a.type==="warning"?"alert":"check"} size={13}
                    color={a.type==="danger"?"#C0392B":a.type==="warning"?"#C47B0A":"#1A7F50"} s={{marginTop:1}}/>
                  <span style={{fontSize:12,color:"#444",lineHeight:1.4}}>{a.msg}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <Card title="פרויקטים אחרונים" action={
          <div style={{display:"flex",gap:8}}>
            <Btn variant="ghost" size="sm" icon="filter">סינון</Btn>
            <Btn variant="primary" size="sm" icon="add" onClick={()=>onNav("projects")}>הצג הכל</Btn>
          </div>
        }>
          <DataTable columns={columns} rows={PROJECTS} selectedId={selectedRow} onRowClick={r=>setSelectedRow(r.id)}/>
        </Card>
      </div>
    </div>
  );
};

Object.assign(window, { DashboardScreen, PROJECTS, fmt, pct });
