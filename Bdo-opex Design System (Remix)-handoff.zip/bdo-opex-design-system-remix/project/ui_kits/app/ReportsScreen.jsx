// Bdo-opex — Reports Screen (Hebrew)
const { useState } = React;

const ReportsScreen = () => {
  const [activeTab, setActiveTab] = useState("financial");
  const tabs = [
    { id:"financial", label:"דוחות פיננסיים" },
    { id:"progress",  label:"דוחות התקדמות" },
    { id:"variance",  label:"ניתוח סטיות" },
  ];

  const reports = {
    financial: [
      { name:"סיכום תקציבים רבעון ראשון 2024",    date:"2024-03-31", size:"245 KB", status:"success" },
      { name:"דוח הוצאות חודשי — מרץ 2024",       date:"2024-03-31", size:"188 KB", status:"success" },
      { name:"ניתוח תזרים מזומנים Q1",             date:"2024-03-28", size:"312 KB", status:"warning" },
      { name:"דוח התחייבויות פיננסיות",            date:"2024-03-20", size:"97 KB",  status:"success" },
    ],
    progress: [
      { name:"לוח סטטוס פרויקטים — אפריל 2024",   date:"2024-04-01", size:"421 KB", status:"success" },
      { name:"דוח השלמה שבועי W13",                date:"2024-03-30", size:"134 KB", status:"success" },
      { name:"סיכום פרויקטים מאחרים",             date:"2024-03-29", size:"89 KB",  status:"danger"  },
    ],
    variance: [
      { name:"ניתוח סטיות תקציב Q1",              date:"2024-03-31", size:"276 KB", status:"warning" },
      { name:"השוואת תכנון מול ביצוע",             date:"2024-03-25", size:"198 KB", status:"success" },
    ],
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:"#F5F6F8",direction:"rtl"}}>
      <TopBar title="דוחות" subtitle="הפקת והורדת דוחות תפעוליים ופיננסיים"
        actions={<>
          <Btn variant="ghost" size="sm" icon="filter">סינון</Btn>
          <Btn variant="primary" size="sm" icon="add">דוח מותאם אישית</Btn>
        </>}/>

      <div style={{flex:1,overflowY:"auto",padding:24,display:"flex",flexDirection:"column",gap:16}}>
        {/* Quick export cards */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
          {[
            {icon:"barChart", title:"דוח תקציב מקיף",         desc:"סיכום כל התקציבים וההוצאות בפועל",      color:"#0B1F3A"},
            {icon:"chart",    title:"דוח ביצועי פרויקטים",    desc:"מדדי ביצוע מרכזיים לכל פרויקט",        color:"#0E7C6A"},
            {icon:"warning",  title:"דוח סיכונים וסטיות",    desc:"פרויקטים שחרגו מהמסגרת שנקבעה",        color:"#A06A20"},
          ].map(c=>(
            <div key={c.title} style={{background:"#fff",border:"1px solid #e2e5ea",borderRadius:4,
              padding:"18px 20px",boxShadow:"0 1px 3px rgba(0,0,0,0.07)",cursor:"pointer"}}
              onMouseEnter={e=>e.currentTarget.style.borderColor=c.color}
              onMouseLeave={e=>e.currentTarget.style.borderColor="#e2e5ea"}>
              <div style={{marginBottom:10}}><Icon name={c.icon} size={20} color={c.color}/></div>
              <div style={{fontSize:13,fontWeight:600,color:"#0d0d0d",marginBottom:4}}>{c.title}</div>
              <div style={{fontSize:11,color:"#767676",marginBottom:14,lineHeight:1.5}}>{c.desc}</div>
              <Btn variant="ghost" size="sm" icon="download">הורד PDF</Btn>
            </div>
          ))}
        </div>

        {/* Tabs + list */}
        <div style={{background:"#fff",border:"1px solid #e2e5ea",borderRadius:4,boxShadow:"0 1px 3px rgba(0,0,0,0.07)"}}>
          <div style={{display:"flex",borderBottom:"1px solid #e2e5ea",padding:"0 20px"}}>
            {tabs.map(t=>(
              <button key={t.id} onClick={()=>setActiveTab(t.id)}
                style={{padding:"12px 16px",background:"none",border:"none",cursor:"pointer",
                  fontSize:13,fontFamily:"Heebo,sans-serif",fontWeight:activeTab===t.id?600:400,
                  color:activeTab===t.id?"#0B1F3A":"#767676",
                  borderBottom:activeTab===t.id?"2px solid #0B1F3A":"2px solid transparent",
                  marginBottom:"-1px",transition:"color 150ms"}}>
                {t.label}
              </button>
            ))}
          </div>
          <div style={{padding:"8px 0"}}>
            {(reports[activeTab]||[]).map((r,i,arr)=>(
              <div key={i} style={{display:"flex",alignItems:"center",justifyContent:"space-between",
                padding:"12px 20px",borderBottom:i<arr.length-1?"1px solid #f7f8fa":"none",
                transition:"background 120ms"}}
                onMouseEnter={e=>e.currentTarget.style.background="#f7f8fa"}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                <div style={{display:"flex",gap:8,alignItems:"center"}}>
                  <Btn variant="ghost" size="sm" icon="download">הורד</Btn>
                  <span style={{fontSize:11,color:"#9a9a9a",fontFamily:"'IBM Plex Mono',monospace"}}>{r.size}</span>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:12}}>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:13,fontWeight:500,color:"#0d0d0d"}}>{r.name}</div>
                    <div style={{fontSize:11,color:"#9a9a9a",marginTop:2,fontFamily:"'IBM Plex Mono',monospace"}}>{r.date}</div>
                  </div>
                  <div style={{width:32,height:32,background:"#f7f8fa",borderRadius:4,
                    display:"flex",alignItems:"center",justifyContent:"center",border:"1px solid #e2e5ea"}}>
                    <Icon name="report" size={14} color="#767676"/>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { ReportsScreen });
