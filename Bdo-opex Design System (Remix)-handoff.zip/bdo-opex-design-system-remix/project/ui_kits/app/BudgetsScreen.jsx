// Bdo-opex — Budgets Screen (Hebrew)
const { useState } = React;

const BUDGETS = [
  { id:1, code:"BDG-Q1-001", name:"תקציב תשתית דיגיטלית Q1",      total:2500000, allocated:2100000, spent:1820000, status:"success", statusLabel:"בתחום" },
  { id:2, code:"BDG-Q1-002", name:"תקציב רכש וספקים",              total:850000,  allocated:850000,  spent:850000,  status:"neutral", statusLabel:"נוצל במלואו" },
  { id:3, code:"BDG-Q1-003", name:"תקציב יעילות תפעולית",          total:1200000, allocated:900000,  spent:430000,  status:"warning", statusLabel:"בבדיקה" },
  { id:4, code:"BDG-Q2-001", name:"תקציב טרנספורמציה פיננסית Q2",  total:3100000, allocated:500000,  spent:120000,  status:"info",    statusLabel:"חדש" },
  { id:5, code:"BDG-Q1-005", name:"תקציב סקירת מערכות",            total:600000,  allocated:600000,  spent:680000,  status:"danger",  statusLabel:"חריגה" },
];

const BudgetsScreen = () => {
  const [selected, setSelected] = useState(1);
  const sel = BUDGETS.find(b=>b.id===selected);

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:"#F5F6F8",direction:"rtl"}}>
      <TopBar title="תקציבים" subtitle="ניהול ומעקב אחר תקציבים מאושרים"
        actions={<>
          <Btn variant="ghost" size="sm" icon="download">ייצוא</Btn>
          <Btn variant="primary" size="sm" icon="add">תקציב חדש</Btn>
        </>}/>

      <div style={{flex:1,overflow:"hidden",display:"flex"}}>
        {/* List */}
        <div style={{width:380,background:"#fff",borderLeft:"1px solid #e2e5ea",
          display:"flex",flexDirection:"column",flexShrink:0,overflowY:"auto"}}>
          <div style={{padding:"12px 16px",borderBottom:"1px solid #f0f1f4"}}>
            <Input placeholder="חיפוש בתקציבים..." icon="search"/>
          </div>
          {BUDGETS.map(b=>{
            const usePct = Math.round((b.spent/b.total)*100);
            const over = b.spent > b.total;
            return (
              <div key={b.id} onClick={()=>setSelected(b.id)}
                style={{padding:"14px 16px",borderBottom:"1px solid #f0f1f4",cursor:"pointer",
                  background:selected===b.id?"#E1EDF8":"transparent",
                  borderRight:selected===b.id?"2px solid #0B1F3A":"2px solid transparent",
                  transition:"background 120ms"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
                  <Badge variant={b.status}>{b.statusLabel}</Badge>
                  <div style={{fontSize:13,fontWeight:600,color:"#0d0d0d",textAlign:"right"}}>{b.name}</div>
                </div>
                <div style={{fontSize:11,color:"#9a9a9a",fontFamily:"'IBM Plex Mono',monospace",marginBottom:8,textAlign:"right"}}>{b.code}</div>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <span style={{fontSize:11,color:over?"#A03030":"#767676",fontFamily:"'IBM Plex Mono',monospace",direction:"ltr"}}>{usePct}%</span>
                  <div style={{flex:1,height:4,background:"#e2e5ea",borderRadius:2,overflow:"hidden"}}>
                    <div style={{width:`${Math.min(usePct,100)}%`,height:"100%",
                      background:over?"#A03030":usePct>80?"#A06A20":"#0B1F3A",borderRadius:2}}/>
                  </div>
                  <span style={{fontSize:11,color:"#767676"}}>{fmt(b.total)}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Detail */}
        {sel && (
          <div style={{flex:1,overflowY:"auto",padding:24,display:"flex",flexDirection:"column",gap:16}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
              <div style={{display:"flex",gap:8}}>
                <Btn variant="outline" size="sm" icon="edit">עריכה</Btn>
                <Btn variant="ghost" size="sm" icon="download">דוח</Btn>
              </div>
              <div>
                <div style={{fontSize:20,fontWeight:700,color:"#0d0d0d"}}>{sel.name}</div>
                <div style={{fontSize:12,color:"#9a9a9a",fontFamily:"'IBM Plex Mono',monospace",marginTop:2}}>{sel.code}</div>
              </div>
            </div>

            <div style={{display:"flex",gap:12}}>
              {[
                {label:"תקציב כולל",    val:fmt(sel.total),                          color:"#0d0d0d"},
                {label:"מוקצה",         val:fmt(sel.allocated),                      color:"#0B1F3A"},
                {label:"בוצע",          val:fmt(sel.spent),                          color:sel.spent>sel.total?"#A03030":"#2E7D56"},
                {label:"יתרה",          val:fmt(Math.abs(sel.total-sel.spent)),      color:sel.spent>sel.total?"#A03030":"#444"},
              ].map(m=>(
                <div key={m.label} style={{flex:1,background:"#fff",border:"1px solid #e2e5ea",
                  borderRadius:4,padding:"14px 16px",boxShadow:"0 1px 3px rgba(0,0,0,0.06)"}}>
                  <div style={{fontSize:11,color:"#767676",marginBottom:6}}>{m.label}</div>
                  <div style={{fontSize:15,fontWeight:700,color:m.color,fontFamily:"'IBM Plex Mono',monospace"}}>{m.val}</div>
                </div>
              ))}
            </div>

            <Card title="פירוט הוצאות">
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                {[
                  {cat:"משאבי אנוש",      val:Math.round(sel.spent*0.42)},
                  {cat:"רכש וספקים",      val:Math.round(sel.spent*0.28)},
                  {cat:"חוזים חיצוניים",  val:Math.round(sel.spent*0.18)},
                  {cat:"תפעול ותחזוקה",   val:Math.round(sel.spent*0.12)},
                ].map(c=>{
                  const p = Math.round((c.val/sel.total)*100);
                  return (
                    <div key={c.cat}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                        <span style={{fontSize:11,color:"#767676",fontFamily:"'IBM Plex Mono',monospace"}}>{p}%</span>
                        <span style={{fontSize:12,color:"#444"}}>{c.cat}</span>
                      </div>
                      <div style={{height:6,background:"#e2e5ea",borderRadius:3,overflow:"hidden"}}>
                        <div style={{width:`${p}%`,height:"100%",background:"#0B1F3A",borderRadius:3}}/>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>

            <Card title="יומן עסקאות">
              <table style={{width:"100%",borderCollapse:"collapse"}}>
                <thead>
                  <tr>
                    {["תאריך","תיאור","סכום","סוג"].map(h=>(
                      <th key={h} style={{padding:"0 0 8px",fontSize:11,fontWeight:600,
                        textTransform:"uppercase",letterSpacing:"0.04em",color:"#767676",
                        textAlign:"right",borderBottom:"1px solid #f0f1f4"}}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    {date:"2024-03-15",desc:"תשלום לספקים Q1",        amount:320000, type:"חיוב"},
                    {date:"2024-03-10",desc:"שכר צוות הפרויקט",       amount:185000, type:"חיוב"},
                    {date:"2024-03-05",desc:"העברת תקציב נוסף",       amount:200000, type:"זיכוי"},
                    {date:"2024-02-28",desc:"חוזה פיתוח חיצוני",      amount:95000,  type:"חיוב"},
                    {date:"2024-02-20",desc:"רכש ציוד טכנולוגי",     amount:67000,  type:"חיוב"},
                  ].map((tx,i)=>(
                    <tr key={i}>
                      <td style={{padding:"9px 0",fontSize:12,color:"#767676",fontFamily:"'IBM Plex Mono',monospace",borderBottom:"1px solid #f7f8fa"}}>{tx.date}</td>
                      <td style={{padding:"9px 0",fontSize:13,color:"#1a1a1a",borderBottom:"1px solid #f7f8fa"}}>{tx.desc}</td>
                      <td style={{padding:"9px 0",fontSize:12,fontFamily:"'IBM Plex Mono',monospace",
                        color:tx.type==="זיכוי"?"#2E7D56":"#0d0d0d",borderBottom:"1px solid #f7f8fa"}}>
                        {tx.type==="זיכוי"?"+":"–"} {fmt(tx.amount)}
                      </td>
                      <td style={{padding:"9px 0",borderBottom:"1px solid #f7f8fa"}}>
                        <Badge variant={tx.type==="זיכוי"?"success":"neutral"}>{tx.type}</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

Object.assign(window, { BudgetsScreen });
