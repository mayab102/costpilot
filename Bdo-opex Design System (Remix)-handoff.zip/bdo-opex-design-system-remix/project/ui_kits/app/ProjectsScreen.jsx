// Bdo-opex — Projects Screen (Hebrew)
const { useState } = React;

const ProjectsScreen = ({ onNav }) => {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const filtered = PROJECTS.filter(p =>
    p.name.includes(search) || p.code.includes(search) || p.manager.includes(search)
  );

  const columns = [
    { key:"code",    label:"קוד",         mono:true },
    { key:"name",    label:"שם הפרויקט" },
    { key:"budget",  label:"תקציב",       mono:true, render:v=>fmt(v) },
    { key:"spent",   label:"בוצע",        mono:true, render:v=>fmt(v) },
    { key:"remain",  label:"יתרה",        mono:true, render:(_,r)=>{
      const rem = r.budget - r.spent;
      return <span style={{color:rem<0?"#C0392B":"#1A7F50",fontFamily:"'IBM Plex Mono',monospace",fontSize:12}}>
        {fmt(Math.abs(rem))}{rem<0?" (גרעון)":""}
      </span>;
    }},
    { key:"status",  label:"סטטוס", render:(_,r)=><Badge variant={r.status}>{r.statusLabel}</Badge> },
    { key:"manager", label:"מנהל" },
    { key:"actions", label:"", render:(_,r)=>(
      <div style={{display:"flex",gap:4,justifyContent:"flex-end"}}>
        <button onClick={e=>{e.stopPropagation();setSelected(r);}}
          style={{background:"none",border:"none",cursor:"pointer",color:"#767676",padding:4,borderRadius:4}}
          onMouseEnter={e=>e.currentTarget.style.background="#f0f1f4"}
          onMouseLeave={e=>e.currentTarget.style.background="none"}>
          <Icon name="edit" size={14}/>
        </button>
        <button onClick={e=>e.stopPropagation()}
          style={{background:"none",border:"none",cursor:"pointer",color:"#767676",padding:4,borderRadius:4}}
          onMouseEnter={e=>e.currentTarget.style.background="#f0f1f4"}
          onMouseLeave={e=>e.currentTarget.style.background="none"}>
          <Icon name="trash" size={14}/>
        </button>
      </div>
    )},
  ];

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100%",background:"#F5F6F8",direction:"rtl"}}>
      <TopBar title="פרויקטים" subtitle={`${PROJECTS.length} פרויקטים רשומים`} actions={<>
        <Btn variant="ghost" size="sm" icon="download">ייצוא CSV</Btn>
        <Btn variant="primary" size="sm" icon="add" onClick={()=>setShowModal(true)}>הוסף פרויקט</Btn>
      </>}/>

      <div style={{flex:1,overflowY:"auto",padding:24,display:"flex",flexDirection:"column",gap:16}}>
        <div style={{display:"flex",gap:12,alignItems:"center"}}>
          <div style={{flex:1}}>
            <Input placeholder="חיפוש לפי שם, קוד או מנהל..." icon="search"
              value={search} onChange={e=>setSearch(e.target.value)}/>
          </div>
          <Btn variant="ghost" size="md" icon="filter">סינון מתקדם</Btn>
          <select style={{height:36,border:"1px solid #e2e5ea",borderRadius:4,padding:"0 12px",
            fontFamily:"Heebo,sans-serif",fontSize:13,color:"#444",background:"#fff",direction:"rtl"}}>
            <option>כל הסטטוסים</option>
            <option>פעיל</option>
            <option>בבדיקה</option>
            <option>הושלם</option>
          </select>
        </div>

        <div style={{display:"flex",gap:12}}>
          {[
            {label:"סך התקציבים",  val:"₪ 8,250,000", color:"#0B1F3A"},
            {label:"סך הביצוע",   val:"₪ 3,900,000", color:"#0E7C6A"},
            {label:"סך הגרעון",   val:"₪ 80,000",    color:"#C0392B"},
          ].map(s=>(
            <div key={s.label} style={{background:"#fff",border:"1px solid #e2e5ea",borderRadius:4,
              padding:"10px 16px",flex:1,boxShadow:"0 1px 3px rgba(0,0,0,0.06)"}}>
              <div style={{fontSize:11,color:"#767676",marginBottom:4}}>{s.label}</div>
              <div style={{fontSize:16,fontWeight:700,color:s.color,fontFamily:"'IBM Plex Mono',monospace"}}>{s.val}</div>
            </div>
          ))}
        </div>

        <DataTable columns={columns} rows={filtered} onRowClick={r=>setSelected(r)} selectedId={selected?.id}/>

        {filtered.length === 0 && (
          <div style={{textAlign:"center",padding:"48px 0",color:"#9a9a9a"}}>
            <Icon name="search" size={32} color="#dedede"/>
            <div style={{marginTop:12,fontSize:14}}>לא נמצאו תוצאות</div>
            <div style={{fontSize:12,marginTop:4}}>נסה מונח חיפוש אחר</div>
          </div>
        )}
      </div>

      {showModal && (
        <div style={{position:"fixed",inset:0,background:"rgba(11,31,58,0.45)",display:"flex",
          alignItems:"center",justifyContent:"center",zIndex:50,backdropFilter:"blur(4px)"}}>
          <div style={{background:"#fff",borderRadius:4,width:520,boxShadow:"0 8px 24px rgba(0,0,0,0.14)",
            direction:"rtl",overflow:"hidden"}}>
            <div style={{padding:"16px 24px",borderBottom:"1px solid #e2e5ea",display:"flex",
              justifyContent:"space-between",alignItems:"center"}}>
              <button onClick={()=>setShowModal(false)}
                style={{background:"none",border:"none",cursor:"pointer",color:"#767676",padding:4}}>
                <Icon name="chevronLeft" size={18}/>
              </button>
              <div style={{fontSize:16,fontWeight:700,color:"#0d0d0d"}}>הוספת פרויקט חדש</div>
            </div>
            <div style={{padding:24,display:"flex",flexDirection:"column",gap:16}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                <Input label="שם הפרויקט" placeholder="הכנס שם פרויקט"/>
                <Input label="קוד פרויקט" placeholder="PRJ-2024-XXX"/>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                <Input label="תקציב מאושר (₪)" placeholder="0"/>
                <Input label="מנהל פרויקט" placeholder="שם מלא"/>
              </div>
              <div>
                <label style={{fontSize:12,fontWeight:500,color:"#444",display:"block",marginBottom:4}}>סוג פרויקט</label>
                <select style={{width:"100%",height:36,border:"1px solid #e2e5ea",borderRadius:4,
                  padding:"0 12px",fontFamily:"Heebo,sans-serif",fontSize:14,direction:"rtl",background:"#fff"}}>
                  <option>פיתוח תשתיות</option>
                  <option>פרויקט פיננסי</option>
                  <option>יעילות תפעולית</option>
                  <option>טרנספורמציה דיגיטלית</option>
                </select>
              </div>
              <div>
                <label style={{fontSize:12,fontWeight:500,color:"#444",display:"block",marginBottom:4}}>תיאור הפרויקט</label>
                <textarea style={{width:"100%",border:"1px solid #e2e5ea",borderRadius:4,padding:"10px 12px",
                  fontFamily:"Heebo,sans-serif",fontSize:14,direction:"rtl",textAlign:"right",
                  resize:"vertical",minHeight:80,outline:"none"}} placeholder="תיאור קצר של הפרויקט ומטרותיו..."/>
              </div>
            </div>
            <div style={{padding:"14px 24px",borderTop:"1px solid #e2e5ea",display:"flex",
              justifyContent:"flex-start",gap:8}}>
              <Btn variant="outline" onClick={()=>setShowModal(false)}>ביטול</Btn>
              <Btn variant="primary" icon="check" onClick={()=>setShowModal(false)}>שמור פרויקט</Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

Object.assign(window, { ProjectsScreen });
